﻿import numpy as np
import time
from app.services.vectorize import vectorize_binary

binary = np.random.randint(0, 2, (1024, 1024), dtype=np.uint8) * 255
im1 = np.zeros((1024, 1024, 3), dtype=np.uint8)
im2 = np.zeros((1024, 1024, 3), dtype=np.uint8)

print('Testing vectorize_binary with noise...')
start = time.time()
fc, stats = vectorize_binary(binary, im1, im2)
print(f'Done in {time.time()-start:.2f} seconds. Patches: {len(stats)}')