﻿import requests

url = 'http://127.0.0.1:8000/api/detect'

# Create dummy files
with open('dummy1.png', 'wb') as f:
    f.write(b'89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001e9fa6d000000000049454e44ae426082')
with open('dummy2.png', 'wb') as f:
    f.write(b'89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001e9fa6d000000000049454e44ae426082')

files = {
    't1': ('dummy1.png', open('dummy1.png', 'rb'), 'image/png'),
    't2': ('dummy2.png', open('dummy2.png', 'rb'), 'image/png')
}
data = {
    'model': 'tidal',
    'threshold': 0.5
}

try:
    resp = requests.post(url, files=files, data=data)
    print("STATUS:", resp.status_code)
    print("RESPONSE:", resp.text)
except Exception as e:
    print("ERROR:", e)