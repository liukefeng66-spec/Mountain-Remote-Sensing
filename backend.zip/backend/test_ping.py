﻿import requests
import json
url = 'http://127.0.0.1:8080/api/detect'
files = {
    't1': ('t1.png', open('data/uploads/799d0c06b0d4/t1.png', 'rb'), 'image/png'),
    't2': ('t2.png', open('data/uploads/799d0c06b0d4/t2.png', 'rb'), 'image/png')
}
data = {
    'model': 'tidal',
    'threshold': 0.5
}
resp = requests.post(url, files=files, data=data)
print("Status:", resp.status_code)
print("Response:", resp.text)