﻿from app.services.inference import make_overlay
try:
    make_overlay('nonexistent.tif', 'nonexistent_mask.png', 'out.png')
except Exception as e:
    print("Caught:", type(e), e)