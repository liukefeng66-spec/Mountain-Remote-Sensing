﻿import torch
import numpy as np
from app.model_adapters.fsd import FSDAdapter

print('Initializing FSD Adapter...')
adapter = FSDAdapter('weights/fsd.pth', device='cpu')

print('Creating dummy images...')
im1 = np.random.randint(0, 255, (256, 256, 3), dtype=np.uint8)
im2 = np.random.randint(0, 255, (256, 256, 3), dtype=np.uint8)

print('Running prediction...')
pred = adapter.predict(im1, im2)

print('Prediction shape:', pred.shape)
print('Prediction range:', pred.min(), '-', pred.max())
print('SUCCESS!')