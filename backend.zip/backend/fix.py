﻿import re

with open('app/api/routes.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix literal 
 in the file
content = content.replace('
', '\n')

# Find the for loop and fix its indentation
# It currently looks something like:
#     for m in models:
#               prob,binary...
#       prob_p...

def fix_indent(match):
    lines = match.group(0).split('\n')
    fixed_lines = []
    for line in lines:
        if line.strip() == '':
            fixed_lines.append('')
        elif line.startswith('      for m in models:'):
            fixed_lines.append('    for m in models:')
        else:
            # strip all leading whitespace and add 8 spaces
            fixed_lines.append('        ' + line.lstrip())
    return '\n'.join(fixed_lines)

# Actually, it's easier to just find the whole block and rewrite it cleanly.
start_idx = content.find('    for m in models:')
if start_idx == -1:
    start_idx = content.find('      for m in models:')

end_idx = content.find('    JOBS[job_id]', start_idx)
if end_idx == -1:
    end_idx = content.find('      JOBS[job_id]', start_idx)

if start_idx != -1 and end_idx != -1:
    new_block = '''    for m in models:
        prob, binary = infer_large(im1, im2, m, threshold)
        prob_p, bin_p = save_prediction(result_dir, m, prob, binary)
        overlay_p = result_dir / f"{m}_overlay.png"
        make_overlay(p2, bin_p, overlay_p)
        fc, stats = vectorize_binary(binary, im1, im2, g1)
        geo_p = result_dir / f"{m}_patches.geojson"
        csv_p = result_dir / f"{m}_stats.csv"
        export_geojson(fc, geo_p)
        export_csv(stats, csv_p)
        output[m] = {
            "prob_url": f"/files/results/{job_id}/{prob_p.name}",
            "binary_url": f"/files/results/{job_id}/{bin_p.name}",
            "overlay_url": f"/files/results/{job_id}/{overlay_p.name}",
            "geojson_url": f"/files/results/{job_id}/{geo_p.name}",
            "stats_url": f"/files/results/{job_id}/{csv_p.name}",
            "patch_count": len(stats),
            "total_area_px": round(sum(x["area_px"] for x in stats), 2),
            "stats": stats,
            "image_a_url": f"/files/uploads/{job_id}/{p1.name}",
            "image_b_url": f"/files/uploads/{job_id}/{p2.name}",
            "image_a_path": str(p1),
            "image_b_path": str(p2),
            "overlay_path": str(overlay_p)
        }
'''
    content = content[:start_idx] + new_block + content[end_idx:]

with open('app/api/routes.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed routes.py")