﻿import asyncio
import io
import os
import glob
from fastapi import UploadFile
from app.api.routes import detect

async def main():
    upload_dirs = glob.glob('E:/PycharmProjects/website/backend/data/uploads/*')
    upload_dirs.sort(key=os.path.getmtime, reverse=True)
    latest_dir = upload_dirs[0]
    
    t1_path = os.path.join(latest_dir, 't1.jpg')
    t2_path = os.path.join(latest_dir, 't2.jpg')
    
    with open(t1_path, 'rb') as f1, open(t2_path, 'rb') as f2:
        t1_bytes = f1.read()
        t2_bytes = f2.read()
        
    t1_upload = UploadFile(filename='t1.jpg', file=io.BytesIO(t1_bytes))
    t2_upload = UploadFile(filename='t2.jpg', file=io.BytesIO(t2_bytes))
    
    try:
        res = await detect(t1=t1_upload, t2=t2_upload, model='tidal', threshold=0.5)
        print(res)
    except Exception as e:
        import traceback
        traceback.print_exc()

asyncio.run(main())