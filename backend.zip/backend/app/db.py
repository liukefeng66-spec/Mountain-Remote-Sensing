﻿import sqlite3
from datetime import datetime
from .config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS inspection_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_code TEXT UNIQUE NOT NULL,
  job_id TEXT NOT NULL,
  patch_code TEXT NOT NULL,
  change_type TEXT,
  risk_level TEXT,
  risk_score REAL,
  susceptibility_level TEXT,
  rain_level TEXT,
  area_m2 REAL,
  centroid_lon REAL,
  centroid_lat REAL,
  location_name TEXT,
  priority TEXT,
  status TEXT DEFAULT '待核查',
  risk_reason TEXT,
  suggestion TEXT,
  source_model TEXT,
  created_at TEXT NOT NULL,
  feedback_result TEXT,
  feedback_desc TEXT,
  photo_path TEXT
);

CREATE TABLE IF NOT EXISTS feedback_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    feedback_code TEXT UNIQUE NOT NULL,
    task_id INTEGER,
    task_code TEXT,
    patch_code TEXT,
    feedback_type TEXT NOT NULL,
    review_status TEXT DEFAULT '待审核',
    change_type TEXT,
    risk_level TEXT,
    confidence REAL,
    source_model TEXT,
    note TEXT,
    site_photo_path TEXT,
    annotation_path TEXT,
    created_at TEXT NOT NULL
);
"""

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)

def add_task(task):
    with get_conn() as conn:
        prefix = datetime.now().strftime("TASK-%Y%m%d")
        c = conn.execute("SELECT COUNT(*) FROM inspection_tasks WHERE task_code LIKE ?", (f"%{prefix}%",)).fetchone()[0]
        task_code = f"{prefix}-{c + 1:03d}"
        
        reasons = task.get("risk_reason", [])
        reason_str = "；".join(reasons) if isinstance(reasons, list) else str(reasons)
        
        conn.execute(
            """INSERT INTO inspection_tasks 
            (task_code, job_id, patch_code, change_type, risk_level, risk_score, susceptibility_level, 
            rain_level, area_m2, centroid_lon, centroid_lat, location_name, priority, status, 
            risk_reason, suggestion, source_model, created_at) 
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (task_code, task.get("job_id",""), task.get("patch_id",""), task.get("change_type", "未分类"),
             task.get("risk_level",""), task.get("risk_score",0.0), task.get("susceptibility_level",""),
             task.get("rain_level",""), task.get("area",0.0), task.get("centroid_x"), task.get("centroid_y"),
             task.get("location_name",""), task.get("priority",""), "待核查", reason_str, task.get("suggestion",""),
             task.get("source_model", "TIDAL-Net"), datetime.now().isoformat(timespec="seconds"))
        )
        conn.commit()

def get_task_summary():
    with get_conn() as conn:
        all_count = conn.execute("SELECT COUNT(*) FROM inspection_tasks").fetchone()[0]
        pending = conn.execute("SELECT COUNT(*) FROM inspection_tasks WHERE status='待核查'").fetchone()[0]
        high = conn.execute("SELECT COUNT(*) FROM inspection_tasks WHERE risk_level IN ('高','极高')").fetchone()[0]
        finished = conn.execute("SELECT COUNT(*) FROM inspection_tasks WHERE status IN ('已核查', '需复核')").fetchone()[0]
        return {"total": all_count, "pending": pending, "high_risk": high, "finished": finished}

def list_tasks(filters=None):
    with get_conn() as conn:
        query = "SELECT * FROM inspection_tasks WHERE 1=1"
        params = []
        if filters:
            if filters.get("risk"): query += " AND risk_level=?"; params.append(filters["risk"])
            if filters.get("status"): query += " AND status=?"; params.append(filters["status"])
            if filters.get("priority"): query += " AND priority=?"; params.append(filters["priority"])
            if filters.get("keyword"): 
                query += " AND (task_code LIKE ? OR patch_code LIKE ?)"
                params.extend([f"%{filters['keyword']}%", f"%{filters['keyword']}%"])
        query += " ORDER BY id DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

def get_task(task_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM inspection_tasks WHERE id=?", (task_id,)).fetchone()
        return dict(row) if row else None

def update_task_status(task_id, status):
    with get_conn() as conn:
        conn.execute("UPDATE inspection_tasks SET status=? WHERE id=?", (status, task_id))
        conn.commit()

def save_task_feedback(task_id, result, desc, photo_path):
    with get_conn() as conn:
        status = "需复核" if result == "需复核" else "已核查"
        conn.execute("UPDATE inspection_tasks SET status=?, feedback_result=?, feedback_desc=?, photo_path=? WHERE id=?", 
                     (status, result, desc, photo_path, task_id))
        conn.commit()
        return status

# --- Feedback Specific DB Functions ---
def get_feedback_summary():
    with get_conn() as conn:
        total = conn.execute("SELECT COUNT(*) FROM feedback_samples").fetchone()[0]
        fp = conn.execute("SELECT COUNT(*) FROM feedback_samples WHERE feedback_type='误报' AND review_status!='已作废'").fetchone()[0]
        fn = conn.execute("SELECT COUNT(*) FROM feedback_samples WHERE feedback_type='漏报' AND review_status!='已作废'").fetchone()[0]
        corr = conn.execute("SELECT COUNT(*) FROM feedback_samples WHERE feedback_type='确认正确' AND review_status!='已作废'").fetchone()[0]
        pending = conn.execute("SELECT COUNT(*) FROM feedback_samples WHERE review_status='待审核'").fetchone()[0]
        return {"total": total, "false_positive": fp, "false_negative": fn, "correct": corr, "pending": pending}

def add_feedback_sample(task, feedback_type, note, site_photo_path, annotation_path):
    with get_conn() as conn:
        # Check duplicate
        dup = conn.execute("SELECT 1 FROM feedback_samples WHERE task_id=? AND feedback_type=? AND review_status!='已作废'", 
                           (task['id'], feedback_type)).fetchone()
        if dup: return None
        
        prefix = datetime.now().strftime("FB-%Y%m%d")
        c = conn.execute("SELECT COUNT(*) FROM feedback_samples WHERE feedback_code LIKE ?", (f"%{prefix}%",)).fetchone()[0]
        code = f"{prefix}-{c + 1:03d}"
        
        conn.execute(
            """INSERT INTO feedback_samples 
            (feedback_code, task_id, task_code, patch_code, feedback_type, review_status, change_type, risk_level, 
            confidence, source_model, note, site_photo_path, annotation_path, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (code, task['id'], task['task_code'], task['patch_code'], feedback_type, '待审核', 
             task.get('change_type',''), task.get('risk_level',''), task.get('confidence',0.87), 
             task.get('source_model','TIDAL-Net'), note, site_photo_path, annotation_path, datetime.now().isoformat(timespec="seconds"))
        )
        conn.commit()
        return code

def list_feedbacks(filters=None):
    with get_conn() as conn:
        query = "SELECT * FROM feedback_samples WHERE 1=1"
        params = []
        if filters:
            if filters.get("feedback_type"): query += " AND feedback_type=?"; params.append(filters["feedback_type"])
            if filters.get("review_status"): query += " AND review_status=?"; params.append(filters["review_status"])
            if filters.get("keyword"): 
                query += " AND (feedback_code LIKE ? OR task_code LIKE ? OR patch_code LIKE ?)"
                params.extend([f"%{filters['keyword']}%", f"%{filters['keyword']}%", f"%{filters['keyword']}%"])
        query += " ORDER BY id DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

def update_feedback_review(feedback_id, status):
    with get_conn() as conn:
        conn.execute("UPDATE feedback_samples SET review_status=? WHERE id=?", (status, feedback_id))
        conn.commit()