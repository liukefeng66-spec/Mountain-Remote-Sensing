﻿from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .api.routes import router
from .api.triptych import router as triptych_router
from .config import DATA_DIR
from .db import init_db
app=FastAPI(title="山地慧眼 MountainEye API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(router)
app.include_router(triptych_router, prefix="/api")
app.mount("/files",StaticFiles(directory=DATA_DIR),name="files")
@app.on_event("startup")
def startup(): init_db()