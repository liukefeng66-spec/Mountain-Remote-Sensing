from pathlib import Path
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
RESULT_DIR = DATA_DIR / "results"
EXPORT_DIR = DATA_DIR / "exports"
DB_PATH = DATA_DIR / "mountain_eye.db"
MODEL_DIR = BASE_DIR / "weights"
for d in (DATA_DIR, UPLOAD_DIR, RESULT_DIR, EXPORT_DIR, MODEL_DIR):
    d.mkdir(parents=True, exist_ok=True)
TILE_SIZE = 256
TILE_OVERLAP = 0
DEFAULT_THRESHOLD = 0.5
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff"}