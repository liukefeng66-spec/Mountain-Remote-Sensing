# -*- encoding: utf-8 -*-
# -----------------------------------
# SRCNet.py
# Written by Chnja from WHU
# chj1997@whu.edu.cn
# -----------------------------------
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def drop_path(x, drop_prob: float = 0.0, training: bool = False):
    if drop_prob == 0.0 or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output


class DropPath(nn.Module):
    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training)


class LayerNorm(nn.Module):
    """LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(
                x, self.normalized_shape, self.weight, self.bias, self.eps
            )
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


class GRN(nn.Module):
    """GRN (Global Response Normalization) layer"""

    def __init__(self, dim):
        super().__init__()
        self.gamma = nn.Parameter(torch.zeros(1, 1, 1, dim))
        self.beta = nn.Parameter(torch.zeros(1, 1, 1, dim))

    def forward(self, x):
        Gx = torch.norm(x, p=2, dim=(1, 2), keepdim=True)
        Nx = Gx / (Gx.mean(dim=-1, keepdim=True) + 1e-6)
        return self.gamma * (x * Nx) + self.beta + x


class SRCBlock(nn.Module):
    def __init__(self, dim, drop_rate=0.2, mode="LN"):
        super().__init__()

        self.depthconv1 = nn.Conv2d(dim, dim, kernel_size=1, groups=dim)
        self.depthconv2 = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim)
        self.depthconv3 = nn.Conv2d(dim, dim, kernel_size=5, padding=2, groups=dim)

        if mode == "BN":
            self.norm = nn.BatchNorm2d(dim)
        else:
            self.norm = LayerNorm(dim, data_format="channels_first")

        self.pointconv1 = nn.Linear(dim, 4 * dim)
        self.gelu = nn.GELU()
        self.grn = GRN(4 * dim)

        self.pointconv2 = nn.Linear(4 * dim, dim)

        self.drop_path = DropPath(drop_rate) if drop_rate > 0.0 else nn.Identity()

    def forward(self, x):
        shortcut = x

        x = (self.depthconv1(x) + self.depthconv2(x) + self.depthconv3(x)) / 3
        x = self.norm(x)
        x = x.permute(0, 2, 3, 1).contiguous()
        x = self.pointconv1(x)
        x = self.gelu(x)
        x = self.grn(x)
        x = self.pointconv2(x)
        x = x.permute(0, 3, 1, 2).contiguous()

        x = shortcut + self.drop_path(x)
        return x


class EdgePooling(nn.Module):
    def __init__(self, pool_type, channels):
        super().__init__()
        self.pools = nn.AvgPool2d(3, stride=1, padding=1) if pool_type == "avg" else nn.MaxPool2d(3, stride=1,
                                                                                                  padding=1)
        self.depthwise = nn.Conv2d(
            channels, channels, kernel_size=3, padding=1,
            groups=channels, bias=False
        )
        # 逐点卷积：用 1x1 卷积整合通道信息
        self.pointwise = nn.Conv2d(
            channels, channels, kernel_size=1, bias=False
        )

        # 批归一化：加速收敛，提升训练稳定性
        self.bn1 = nn.BatchNorm2d(channels)
        self.bn2 = nn.BatchNorm2d(channels)

        # 激活函数：LeakyReLU，避免神经元完全失效
        self.act = nn.LeakyReLU(inplace=True)

    def forward(self, x):
        n, c, h, w = x.shape
        # 多尺度池化
        Pool = self.pools(x)
        x = torch.abs(x - Pool)
        x = self.depthwise(x)
        x = self.bn1(x)
        x = self.act(x)

        # 第二步：再做逐点卷积 + BN + 激活
        x = self.pointwise(x)
        x = self.bn2(x)
        x = self.act(x)

        return x


class EdgeEnhance(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels

        # 多尺度双分支池化
        self.avg_branch = EdgePooling("avg", in_channels)  # 多尺度平均池化分支
        self.max_branch = EdgePooling("max", in_channels)  # 多尺度最大池化分支
        self.fuse_conv = nn.Conv2d(2 * in_channels, in_channels, kernel_size=1)  # 融合双分支

        # 添加可学习的权重参数 [7,8](@ref)
        self.spatial_weight = nn.Parameter(torch.tensor(0.1))  # 初始值为1.0

    def forward(self, x):
        n, c, h, w = x.shape
        avg_feat = self.avg_branch(x)  # [N, C, H, W]
        max_feat = self.max_branch(x)  # [N, C, H, W]
        # 双分支拼接与融合
        cat_feat = torch.cat([avg_feat, max_feat], dim=1)  # [N, 2C, H, W]
        spatial_att = self.fuse_conv(cat_feat)  # [N, C, H, W]

        # 应用可学习权重到空间注意力 [7,8](@ref)
        weighted_spatial_att = self.spatial_weight * spatial_att

        return x + weighted_spatial_att


class AttentionFusion(nn.Module):
    """多尺度注意力融合模块（替代原ResidualFusion）"""

    def __init__(self, dim):
        super().__init__()
        self.conv_down = nn.Conv2d(dim * 2, dim, kernel_size=1)
        self.conv_1x1 = nn.Conv2d(dim, dim, kernel_size=1, groups=dim)
        self.conv_3x3 = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim)
        self.conv_5x5 = nn.Conv2d(dim, dim, kernel_size=5, padding=2, groups=dim)
        # 特征融合与归一化
        self.conv = nn.Conv2d(dim * 3, dim, kernel_size=1)
        self.norm = LayerNorm(dim, data_format="channels_first")
        self.gelu = nn.GELU()
        self.sigmoid = nn.Sigmoid()  # 归一化到[0,1]

    def forward(self, attn, attn_diff):
        """
        输入:
            attn: 基础注意力图 (B, C, H, W)
            attn_diff: 差异注意力图 (B, C, H, W)
        输出:
            fused_attn: 融合后的注意力图 (B, C, H, W)
        """
        # 拼接双注意力图作为输入
        x = torch.cat([attn, attn_diff], dim=1)  # (B, 2C, H, W)
        x = self.conv_down(x)
        x1 = self.conv_1x1(x)
        x2 = self.conv_3x3(x)
        x3 = self.conv_5x5(x)
        fused = torch.cat((x1, x2, x3), dim=1)
        fused = self.conv(fused)  # (B, C, H, W)

        # 归一化与激活
        fused = self.gelu(self.norm(fused))
        return self.sigmoid(fused)

class DDEM(nn.Module):
    def __init__(self, in_channels, reduction_ratio=4):
        super(DDEM, self).__init__()
        # 输入预处理（双时相独立）
        self.preprocess = nn.Sequential(
            nn.BatchNorm2d(in_channels),
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.GELU()
        )
        self.Edge = EdgeEnhance(in_channels)
        self.sigmoid = nn.Sigmoid()

        # 特征融合层
        self.Ln_diff = LayerNorm(in_channels, data_format="channels_first")  # 专用于差异特征
        self.fusion_conv = nn.Conv2d(2 * in_channels, in_channels, kernel_size=1)

        self.dilated_conv = nn.Conv2d(
            in_channels,
            in_channels,
            kernel_size=3,
            padding=5,  # 保持空间分辨率不变
            dilation=5,  # 扩张率设为5
            groups=in_channels  # 深度可分离卷积，减少参数量
        )
        # 添加激活函数增强非线性表达能力
        self.act = nn.GELU()

        self.attn_fusion = AttentionFusion(in_channels)

    def forward(self, x_t1, x_t2):
        # 1. 双时相预处理
        x_t1_pre = self.preprocess(x_t1)
        x_t2_pre = self.preprocess(x_t2)

        diff1 = x_t1_pre - x_t2_pre
        diff1 = self.Ln_diff(diff1)
        diff1 = self.dilated_conv(diff1)
        attn_diff1 = self.act(diff1)

        diff2 = x_t2_pre - x_t1_pre
        diff2 = self.Ln_diff(diff2)
        diff2 = self.dilated_conv(diff2)
        attn_diff2 = self.act(diff2)

        diff_attn1 = self.attn_fusion(attn_diff1, x_t1_pre)
        diff_attn2 = self.attn_fusion(attn_diff2, x_t2_pre)

        x_t1_weighted = diff_attn1 * x_t1_pre
        x_t2_weighted = diff_attn2 * x_t2_pre

        x_t1_weighted = self.Edge(x_t1_weighted)
        x_t2_weighted = self.Edge(x_t2_weighted)

        x_t1_out = x_t1_weighted + x_t1
        x_t2_out = x_t2_weighted + x_t2

        return x_t1_out, x_t2_out


class PatchEmb(nn.Module):
    def __init__(self, dim, patch_size):
        super().__init__()
        # 新增的SCA模块（在不同尺度）
        self.ddem1 = DDEM(dim // 4)
        self.ddem2 = DDEM(dim // 2)
        self.ddem3 = DDEM(dim)

        # 下采样步骤
        self.GenPatch1 = nn.Conv2d(3, dim // 4, kernel_size=4, stride=2, padding=1)
        self.bn1 = nn.BatchNorm2d(dim // 4)

        self.GenPatch2 = nn.Conv2d(dim // 4, dim // 2, kernel_size=4, stride=2, padding=1)
        self.bn2 = nn.BatchNorm2d(dim // 2)

        self.GenPatch3 = nn.Conv2d(dim // 2, dim, kernel_size=4, stride=2, padding=1)
        self.bn3 = nn.BatchNorm2d(dim)

    def forward(self, a, b):  # 修改为接受两个输入
        # Step 1: 256x256 -> 128x128 (两个时相分别处理)
        a1 = F.gelu(self.bn1(self.GenPatch1(a)))
        b1 = F.gelu(self.bn1(self.GenPatch1(b)))
        a1, b1 = self.ddem1(a1, b1)  # 双时相交互

        # Step 2: 128x128 -> 64x64
        a2 = F.gelu(self.bn2(self.GenPatch2(a1)))
        b2 = F.gelu(self.bn2(self.GenPatch2(b1)))
        a2, b2 = self.ddem2(a2, b2)  # 双时相交互

        # Step 3: 64x64 -> 32x32
        a3 = self.bn3(self.GenPatch3(a2))
        b3 = self.bn3(self.GenPatch3(b2))
        a3, b3 = self.ddem3(a3, b3)

        return a3, b3  # 返回两个时相的特征


class FEStage(nn.Module):
    def __init__(self, dim, n1):
        super().__init__()
        self.n1 = n1
        self.blocks = nn.ModuleList([SRCBlock(dim) for _ in range(n1)])
        self.checks = nn.ModuleList([PIM(dim) for _ in range(n1)])

    def forward(self, x1, x2):
        diffList = torch.tensor(0.0, dtype=x1.dtype, device=x1.device)
        for num in range(0, self.n1):
            chk = self.checks[num]
            blk = self.blocks[num]

            x1, x2 = blk(x1), blk(x2)
            x1w = self.WindowMaskSimple(x1)
            diff = chk(x1, x1w) - x1
            diffList += torch.mean(diff * diff)
            x2w = self.NoiseSimple(x2)
            diff = chk(x2, x2w) - x2
            diffList += torch.mean(diff * diff)
            x1, x2 = chk(x1, x2), chk(x2, x1)
        return x1, x2, diffList / self.n1 / 2

    def WindowMaskSimple(self, x, drop_prob=0.5):
        # shape = x.shape
        keep_prob = 1 - drop_prob
        random_tensor = torch.rand(x.shape, dtype=x.dtype, device=x.device)
        random_tensor = random_tensor + keep_prob
        random_tensor = random_tensor.floor_()
        x = x.div(keep_prob) * random_tensor

        shape = (x.shape[0], 1, 1, x.shape[3])
        random_tensor = torch.rand(shape, dtype=x.dtype, device=x.device)
        random_tensor = random_tensor + keep_prob
        random_tensor = random_tensor.floor_()
        return x.div(keep_prob) * random_tensor

    def NoiseSimple(self, x, drop_prob=0.5):
        # shape = x.shape
        random_tensor = torch.rand(x.shape, dtype=x.dtype, device=x.device)
        random_tensor = (random_tensor * 2 - 1) * drop_prob + 1
        return x * random_tensor


class TIAM(nn.Module):
    def __init__(self):
        super(TIAM, self).__init__()
        # 卷积层保持不变，仍然用于融合4个通道的特征
        self.conv = nn.Sequential(
            nn.Conv2d(3, 1, kernel_size=7, padding=3, groups=1),
            nn.SiLU(),
            nn.Conv2d(1, 1, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x1, x2):
        mean_x1 = torch.mean(x1, dim=1, keepdim=True)
        max_x1, _ = torch.max(x1, dim=1, keepdim=True)
        min_x1, _ = torch.min(x1, dim=1, keepdim=True)

        mean_x2 = torch.mean(x2, dim=1, keepdim=True)
        max_x2, _ = torch.max(x2, dim=1, keepdim=True)
        min_x2, _ = torch.min(x2, dim=1, keepdim=True)

        fused_mean = torch.max(mean_x1, mean_x2)
        fused_max = torch.max(max_x1, max_x2)
        fused_min = torch.max(min_x1, min_x2)

        pool_final = torch.cat([fused_mean, fused_max, fused_min], dim=1)

        final_attention = self.conv(pool_final)

        x1_weighted = x1 * final_attention
        x2_weighted = x2 * final_attention

        return x1_weighted + x1, x2_weighted + x2


class PIM(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.prob = nn.Conv2d(dim, dim, 1)
        self.sigmoid = nn.Sigmoid()
        self.TIAM = TIAM()

        self.b = 0.5

    def forward(self, x1t, x2t):
        x1t, x2t = self.TIAM(x1t, x2t)
        P1, P2 = self.prob(x1t), self.prob(x2t)
        P1, P2 = self.sigmoid(P1), self.sigmoid(P2)
        P1 = P1 * (1 - self.b) + self.b
        x = P1 * x1t + (1 - P1) * P2 * x2t + (1 - P1) * (1 - P2) * (x1t + x2t) / 2
        return x


class Repatch(nn.Module):
    def __init__(self, in_ch, patch_size):
        super().__init__()
        self.patchup = nn.ConvTranspose2d(
            in_ch, 2, kernel_size=patch_size, stride=patch_size
        )
        self.softmax = nn.Softmax(dim=1)

    def forward(self, a, b):
        x1, x2 = self.patchup(a), self.patchup(b)
        x1P, x2P = self.softmax(x1), self.softmax(x2)
        spA = torch.zeros_like(x1P)
        spA[:, 1, :, :] = (
                x1P[:, 1, :, :] * x2P[:, 0, :, :] + x1P[:, 0, :, :] * x2P[:, 1, :, :]
        )
        spA[:, 0, :, :] = (
                x1P[:, 0, :, :] * x2P[:, 0, :, :] + x1P[:, 1, :, :] * x2P[:, 1, :, :]
        )
        return spA


class MJFM(nn.Module):
    def __init__(self, dim, k_list, m):
        super().__init__()
        self.k_list = k_list
        self.m = m
        self.num_scales = len(k_list)

        # 初始化可学习权重参数
        self.scale_weights = nn.Parameter(torch.ones(self.num_scales))

        self.scale_heads = nn.ModuleList()
        for k in k_list:
            head = nn.ModuleDict({
                'prob': nn.Linear(dim // k, m),
                'result': nn.Conv2d(dim // k * m, dim // k * m, kernel_size=1, groups=m)
            })
            self.scale_heads.append(head)

        self.softmax = nn.Softmax(dim=4)
        self.d1line = nn.Parameter(torch.tensor(
            [1] * (m // 2) + [1] * (m // 4) + [-1] * (m // 4)
        ).reshape(1, 1, m, 1, 1, 1), requires_grad=False)

        self.d2line = nn.Parameter(torch.tensor(
            [1] * (m // 2) + [-1] * (m // 4) + [1] * (m // 4)
        ).reshape(1, 1, m, 1, 1, 1), requires_grad=False)

    def forward(self, x1, x2):
        outputs = []
        B, C, H, W = x1.shape

        # 生成各尺度特征
        for idx, k in enumerate(self.k_list):
            l = C // k
            m = x1 + x2
            m = m.view(B, k, l, H, W).permute(0, 1, 3, 4, 2)
            prob = self.scale_heads[idx]['prob'](m)
            prob = self.softmax(prob)

            d1 = x1.view(B, k, 1, l, H, W).repeat(1, 1, self.m, 1, 1, 1)
            d2 = x2.view(B, k, 1, l, H, W).repeat(1, 1, self.m, 1, 1, 1)
            d = d1 * self.d1line + d2 * self.d2line

            d = d.reshape(B * k, self.m * l, H, W)
            result = self.scale_heads[idx]['result'](d)
            result = result.reshape(B, k, self.m, l, H, W)
            prob = prob.unsqueeze(4)

            result = result.permute(0, 1, 4, 5, 3, 2)
            out = result * prob
            out = torch.sum(out, dim=5)
            out = out.permute(0, 1, 4, 2, 3).reshape(B, C, H, W)
            outputs.append(out)

        # 可学习的多尺度融合
        stacked_outputs = torch.stack(outputs, dim=0)  # [num_scales, B, C, H, W]

        # 计算归一化权重
        weights = F.softmax(self.scale_weights, dim=0)

        # 调整权重维度用于广播 [num_scales] -> [1, num_scales, 1, 1, 1]
        weighted_outputs = stacked_outputs * weights.view(-1, 1, 1, 1, 1)

        # 加权求和
        fused_output = torch.sum(weighted_outputs, dim=0)

        return fused_output

class GCSA(nn.Module):
    def __init__(self, in_channels, rate=4):
        super(GCSA, self).__init__()

        # 通道注意力子模块
        self.channel_attention = nn.Sequential(
            nn.Linear(in_channels, int(in_channels / rate)),  # 线性层，将通道数缩减到1/rate
            nn.ReLU(inplace=True),  # ReLU激活函数
            nn.Linear(int(in_channels / rate), in_channels)  # 线性层，将通道数恢复到原始大小
        )

        # 空间注意力子模块
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(in_channels, int(in_channels / rate), kernel_size=7, padding=3),  # 7x7卷积，通道数缩减到1/rate
            nn.BatchNorm2d(int(in_channels / rate)),  # 批归一化
            nn.ReLU(inplace=True),  # ReLU激活函数
            nn.Conv2d(int(in_channels / rate), in_channels, kernel_size=7, padding=3),  # 7x7卷积，恢复到原始通道数
            nn.BatchNorm2d(in_channels)  # 批归一化
        )

    # 通道洗牌操作函数
    def channel_shuffle(self, x, groups):
        batchsize, num_channels, height, width = x.size()
        channels_per_group = num_channels // groups
        # 调整形状，分组
        x = x.view(batchsize, groups, channels_per_group, height, width)
        # 转置，打乱组内通道
        x = torch.transpose(x, 1, 2).contiguous()
        # 恢复原始形状
        x = x.view(batchsize, -1, height, width)

        return x

    # 前向传播函数
    def forward(self, x):
        b, c, h, w = x.shape  # 获取输入张量的形状
        x_permute = x.permute(0, 2, 3, 1).view(b, -1, c)  # 调整形状，便于通道注意力操作
        x_att_permute = self.channel_attention(x_permute).view(b, h, w, c)  # 应用通道注意力
        x_channel_att = x_att_permute.permute(0, 3, 1, 2).sigmoid()  # 调整回原始形状，并应用Sigmoid激活函数

        x = x * x_channel_att  # 将输入特征图与通道注意力图逐元素相乘

        x = self.channel_shuffle(x, groups=4) # 添加通道洗牌操作[根据自己的任务设定组数,2也行,大于4也行，看效果选择]

        x_spatial_att = self.spatial_attention(x).sigmoid()  # 应用空间注意力，并应用Sigmoid激活函数

        out = x * x_spatial_att  # 将输入特征图与空间注意力图逐元素相乘

        return out  # 返回输出特征图


class ResidualFusion(nn.Module):
    def __init__(self, dim):
        super(ResidualFusion, self).__init__()
        # 多尺度深度卷积特征强化
        self.conv_1x1 = nn.Conv2d(dim * 3, dim, kernel_size=1, groups=dim)
        self.conv_3x3 = nn.Conv2d(dim * 3, dim, kernel_size=3, padding=1, groups=dim)
        self.conv_5x5 = nn.Conv2d(dim * 3, dim, kernel_size=5, padding=2, groups=dim)

        # 特征融合与残差连接
        self.conv_fusion = nn.Conv2d(dim, dim, kernel_size=1)
        self.norm = LayerNorm(dim, data_format="channels_first")
        self.gelu = nn.GELU()

    def forward(self, G1, G2, x):
        # 多尺度特征融合
        fused = torch.cat((G1, G2, x), dim=1)
        x_1x1 = self.conv_1x1(fused)
        x_3x3 = self.conv_3x3(fused)
        x_5x5 = self.conv_5x5(fused)
        fused = (x_1x1 + x_3x3 + x_5x5) / 3
        # 特征压缩与残差连接
        fused = self.conv_fusion(fused)
        fused = self.gelu(self.norm(fused + x))
        return fused


class SRCNet(nn.Module):
    def __init__(self):
        super().__init__()
        patch_size = 8
        dim = 256
        n1 = n2 = 4
        # Patch Embedding
        self.PE = PatchEmb(dim=dim, patch_size=patch_size)
        # Feature Extraction
        self.FES = FEStage(dim, n1)
        # Feature Fusion
        self.repatch = Repatch(in_ch=dim, patch_size=patch_size)
        self.mix = MJFM(dim=dim, k_list=[8, 16, 32], m=8)
        # Change Prediction
        self.CPBlocks = nn.ModuleList([SRCBlock(dim) for _ in range(n2)])
        # Patch Combining
        self.patchup = nn.ConvTranspose2d(
            dim, 32, kernel_size=patch_size, stride=patch_size
        )
        self.norm = nn.BatchNorm2d(32)
        self.gelu = nn.GELU()
        self.final = nn.Conv2d(32, 2, kernel_size=1)
        # Loss
        self.sigma = nn.Parameter(torch.ones(3))
        # Learnable Fusion Gate
        self.fusion_conv = nn.Conv2d(2 * dim, dim, kernel_size=1)
        self.GCSA = GCSA(in_channels=256)
        self.Residual = ResidualFusion(dim=dim)

    def forward(self, a, b):
        if self.training:
            a, b = self.randomAB(a, b)
        # Patch Embedding
        x1, x2 = self.PE(a, b)
        # Feature Extraction
        x1, x2, diff = self.FES(x1, x2)
        # Feature Fusion
        Dis = self.repatch(x1, x2)
        G1 = self.GCSA(x1)
        G2 = self.GCSA(x2)
        x = self.mix(x1, x2)
        x = self.Residual(G1, G2, x)
        # Change Prediction
        for blk in self.CPBlocks:
            x = blk(x)
        # Patch Combining
        out = self.patchup(x)
        out = self.gelu(self.norm(out))
        out = self.final(out)
        return (out,), (Dis,), (diff,), self.sigma

    def randomAB(self, a, b):
        shape = (a.shape[0], 1, 1, 1)
        random_tensor = torch.rand(shape, dtype=a.dtype, device=a.device)
        random_tensor = random_tensor + 0.5
        random_tensor = random_tensor.floor_()
        return a * random_tensor + b * (1 - random_tensor), b * random_tensor + a * (
                1 - random_tensor
        )