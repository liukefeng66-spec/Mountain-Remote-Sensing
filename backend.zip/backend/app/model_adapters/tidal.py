﻿from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from .base import ChangeModelAdapter
from .tidal_net import SRCNet

class TIDALAdapter(ChangeModelAdapter):
    name = "TIDAL-Net"
    
    def __init__(self, weight_path: str | None = None, device: str | None = None):
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.weight_path = weight_path
        
        self.model = SRCNet()
        
        if weight_path and Path(weight_path).exists():
            try:
                ckpt = torch.load(weight_path, map_location=self.device)
                state_dict = ckpt.get('state_dict', ckpt)
                
                # Check if the user's trained weights are missing the 3rd branch (e.g. newly trained epoch_88.pth)
                has_ddem3 = any('ddem3' in k or 'sca3' in k for k in state_dict.keys())
                if not has_ddem3:
                    class DummyDDEM(torch.nn.Module):
                        def forward(self, a, b): return a, b
                    self.model.PE.ddem3 = DummyDDEM()

                # Rename old layers to new names if needed
                mapped_state_dict = {
                    k.replace('.sca1', '.ddem1').replace('.sca2', '.ddem2').replace('.sca3', '.ddem3').replace('.SPA.', '.TIAM.'): v 
                    for k, v in state_dict.items()
                }
                self.model.load_state_dict(mapped_state_dict, strict=False)
                print(f"Successfully loaded TIDAL-Net weights from {weight_path}")
            except Exception as e:
                print(f"Failed to load weights: {e}")
                
        self.model.to(self.device)
        self.model.eval()

    def _prep(self, x):
        # inputs are 0-255 float32
        x = torch.from_numpy(x).float().permute(2,0,1).unsqueeze(0)
        return x.to(self.device)

    @torch.inference_mode()
    def predict(self, t1: np.ndarray, t2: np.ndarray) -> np.ndarray:
        outputs = self.model(self._prep(t1), self._prep(t2))
        out = outputs[0][0]
        prob = F.softmax(out, dim=1)
        prob_map = prob[0, 1, :, :].cpu().numpy()
        return prob_map