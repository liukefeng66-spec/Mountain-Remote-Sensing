from abc import ABC, abstractmethod
import numpy as np
class ChangeModelAdapter(ABC):
    name = "base"
    @abstractmethod
    def predict(self, t1: np.ndarray, t2: np.ndarray) -> np.ndarray:
        '''Return HxW probability map in [0,1].'''