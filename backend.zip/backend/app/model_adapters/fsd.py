import numpy as np
import torch
from .base import ChangeModelAdapter
from .fsd_net.Networks import MyNet

class FSDAdapter(ChangeModelAdapter):
    name = "FSD-Net"

    def __init__(self, weight_path: str | None = None, device: str | None = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.weight_path = weight_path or "weights/fsd.pth"
        self.model = MyNet(n_classes=2, beta=512, dim=512, numhead=1)
        
        try:
            state_dict = torch.load(self.weight_path, map_location=self.device)
            self.model.load_state_dict(state_dict, strict=True)
            print(f"[{self.name}] 成功加载权重: {self.weight_path}")
        except Exception as e:
            print(f"[{self.name}] 权重加载失败: {e}，将使用未初始化模型进行兜底测试。")
            
        self.model.to(self.device)
        self.model.eval()

    @torch.inference_mode()
    def predict(self, t1: np.ndarray, t2: np.ndarray) -> np.ndarray:
        x1 = torch.from_numpy(t1).float().permute(2,0,1).unsqueeze(0).to(self.device)/255.0
        x2 = torch.from_numpy(t2).float().permute(2,0,1).unsqueeze(0).to(self.device)/255.0
        
        y = self.model(x1, x2)
        
        # Depending on MyNet's output format, extract the logits.
        if isinstance(y, (tuple,list)): y = y[0] # Try getting the first or main output
        if isinstance(y, dict): y = y.get("out", next(iter(y.values())))
        
        if y.shape[1] == 2:
            # 2 classes -> apply softmax and get the positive class
            y = torch.softmax(y, dim=1)[:, 1, :, :]
        else:
            y = torch.sigmoid(y) if y.min() < 0 or y.max() > 1 else y
            
        return y.squeeze().float().cpu().numpy()