﻿import torch
from torch import nn
import torch.nn.functional as F
from torchvision import models



import math
from .DRB import DRB
from .SCB import SCB
from .FAD import FAD_Block

epsilon = 1e-14


class vgg16_base(nn.Module):
    def __init__(self):
        super(vgg16_base, self).__init__()
        feats = list(models.vgg16(pretrained=False).features)[:30]
        self.feats = nn.ModuleList(feats).eval()

    def forward(self, x):
        feat = []
        for i, model in enumerate(self.feats):
            x = model(x)
            if i in {3, 8, 15, 22, 29}:
                feat.append(x)
        return feat


class Linear_qkv(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(Linear_qkv, self).__init__()
        self.linear_qkv = nn.Linear(dim_in, dim_out, bias=False)

    def forward(self, x):
        return self.linear_qkv(x)


class SingleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.single_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.single_conv(x)


class SingleConv3(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.single_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.single_conv(x)


class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        return self.conv(x)


class MyNet(nn.Module):
    def __init__(self, n_classes=2, beta=2.0, dim=512, numhead=1, n_channels=3, bilinear=True):
        super(MyNet, self).__init__()
        self.n_channels = n_channels
        self.bilinear = bilinear
        self.base = vgg16_base()
        #self.sig = nn.Sigmoid()


        #self.layernorm1 = nn.LayerNorm([512, 16, 16])
        # self.instancenorm1 = nn.InstanceNorm2d(512)
        self.dec51 = SingleConv3(512, 512)
        self.out5 = OutConv(512, n_classes)

        self.scb5 = SCB(1024, 512)
        self.scb4 = SCB(1024, 512)


        self.fad5 = FAD_Block(512)
        self.fad4 = FAD_Block(512)

        self.drb5 = DRB(512)
        self.drb4 = DRB(256)
        self.drb3 = DRB(128)
        self.drb2 = DRB(64)

        #self.dec4 = SingleConv3(1024, 512)
        #self.layernorm2 = nn.LayerNorm([512, 32, 32])
        # self.instancenorm2 = nn.InstanceNorm2d(512)
        self.dec41 = SingleConv3(1024, 256)
        self.out4 = OutConv(512, n_classes)

        self.dec3 = SingleConv3(512, 256)
        self.dec31 = SingleConv3(512, 128)

        self.dec2 = SingleConv3(256, 128)
        self.dec21 = SingleConv3(256, 64)

        self.dec1 = SingleConv3(128, 64)
        self.dec11 = SingleConv3(128, 32)
        self.outc = OutConv(32, n_classes)
        # self.dec5 = SingleConv(32,16)

    def forward(self, xA,xB):
        list_t1 = self.base(xA)
        list_t2 = self.base(xB)
        xA1, xA2, xA3, xA4, xA5 = list_t1[0], list_t1[1], list_t1[2], list_t1[3], list_t1[4]
        xB1, xB2, xB3, xB4, xB5 = list_t2[0], list_t2[1], list_t2[2], list_t2[3], list_t2[4]
        # print(f"xA1.shape:", xA1.shape) # torch.Size([32, 64, 256, 256])
        # print(f"xA2.shape:", xA2.shape) # torch.Size([32, 128, 128, 128])
        # print(f"xA3.shape:", xA3.shape) # torch.Size([32, 256, 64, 64])
        # print(f"xA4.shape:", xA4.shape) # torch.Size([32, 512, 32, 32])
        # print(f"xA5.shape:", xA5.shape) # torch.Size([32, 512, 16, 16])
        b1, c1, h1, w1 = xA1.shape
        b4, c4, h4, w4 = xA4.shape
        b5, c5, h5, w5 = xA5.shape

        xx = torch.cat((xA5, xB5), dim=1)
        xx = self.scb5(xx)
        x5_diff = self.fad5(xA5, xB5)
        xx5 = self.out5(x5_diff)
        x = torch.mul(x5_diff, xx)  # 512 16 16
        x = self.dec51(x)
        #x = self.UpSample(x)  # 512 32 32
        x = self.drb5(x)


        xx = torch.cat((xA4, xB4), dim=1)
        xx = self.scb4(xx)
        x4_diff = self.fad4(xA4, xB4)
        xx4 = self.out4(x4_diff)
        xx = torch.mul(x4_diff, xx)  # 512 32 32
        x = torch.cat((xx, x), dim=1)  # 1024 32 32
        x = self.dec41(x)  # 256 32 32
        x = self.drb4(x)


        xx = torch.cat((xA3, xB3), dim=1)
        xx = self.dec3(xx)  # 256 64 64
        x = torch.cat((xx, x), dim=1)  # 512 64 64
        x = self.dec31(x)
        x = self.drb3(x)


        xx = torch.cat((xA2, xB2), dim=1)
        xx = self.dec2(xx)  # 128 128 128
        x = torch.cat((xx, x), dim=1)  # 256 128 128
        x = self.dec21(x)  # 64 128 128
        #x = self.UpSample(x)
        x = self.drb2(x)


        xx = torch.cat((xA1, xB1), dim=1).reshape(b1, c1 * 2, h1, w1)
        xx = self.dec1(xx)  # 64 256 256
        x = torch.cat((xx, x), dim=1)  # 128 256 256
        x = self.dec11(x)  # 32 256 256

        logits = self.outc(x)
        # print(f"logits:{logits.shape}")
        return logits, xx4, xx5


if __name__ == '__main__':
    # 1. 定义设备
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    # 2. 实例化模型
    model = MyNet().to(device)

    # 3. 创建虚拟输入 (注意：你的 forward 需要两个输入 xA, xB)
    # 假设输入是 256x256 的图片
    input1 = torch.randn(1, 3, 256, 256).to(device)
    input2 = torch.randn(1, 3, 256, 256).to(device)

    # 4. 计算 FLOPs 和 Params
    # profile 接受的 inputs 必须是一个 tuple，对应 forward 函数的参数
    flops, params = profile(model, inputs=(input1, input2))

    # 5. 格式化输出 (自动转为 M, G)
    flops_fmt, params_fmt = clever_format([flops, params], "%.3f")

    print(f"Model: MyNet")
    print(f"Input Shape: (3, 256, 256)")
    print(f"FLOPs: {flops_fmt}")
    print(f"Params: {params_fmt}")

