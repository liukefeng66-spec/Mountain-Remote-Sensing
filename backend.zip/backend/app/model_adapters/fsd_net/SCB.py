import torch
import torch.nn as nn
import torch.fft as fft


class Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size(0), -1)


class FrequencyChannelAttention(nn.Module):

    def __init__(self, in_channels, reduction_ratio=16):
        super(FrequencyChannelAttention, self).__init__()
        self.in_channels = in_channels

        # 输入维度是 2 * C，因为频域特征包含实部和虚部
        # 为了防止 reduction 后维度为 0，设置最小维度为 4
        hidden_channels = max(in_channels * 2 // reduction_ratio, 4)

        self.mlp = nn.Sequential(
            Flatten(),
            nn.Linear(in_channels * 2, hidden_channels),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_channels, in_channels * 2),
            nn.Sigmoid()
        )

    def forward(self, x_freq):
        # 1. 频域全局统计量 (Spectral Global Pooling)
        # 在频域的空间维度 (H, W) 上取平均，获得每个通道的平均频率响应
        # 输出形状: [B, C] (复数)
        gap_freq = torch.mean(x_freq, dim=(-2, -1))


        # 2. 拼接实部和虚部
        # 将复数特征拆解为实数特征向量，以便输入 MLP
        # 输出形状: [B, 2*C]
        gap_cat = torch.cat([gap_freq.real, gap_freq.imag], dim=1)

        # 3. 动态生成注意力权重
        # 输出形状: [B, 2*C]
        att_weights = self.mlp(gap_cat)

        # 4. 拆分回实部和虚部
        att_real = att_weights[:, :self.in_channels].unsqueeze(-1).unsqueeze(-1)  # [B, C, 1, 1]
        att_imag = att_weights[:, self.in_channels:].unsqueeze(-1).unsqueeze(-1)  # [B, C, 1, 1]

        # 5. 重组为复数权重
        att_complex = torch.complex(att_real, att_imag)

        return att_complex


class SCB(nn.Module):


    def __init__(self, in_channels, out_channels, reduction_ratio=16):
        super(SCB, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels

        self.conv1x1 = nn.Conv2d(in_channels, out_channels, kernel_size=1)

        # 2. 动态频域注意力模块
        self.freq_att = FrequencyChannelAttention(out_channels, reduction_ratio)

        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.SiLU(inplace=True)  # 使用 SiLU 激活

    def forward(self, x):

        # 保存残差边
        shortcut = x

        # 1. 调整通道
        x = self.conv1x1(x)
        B, C, H, W = x.shape

        # 2. 快速傅里叶变换 (FFT)
        # 将空域特征变换到频域
        # rfft2 输出的最后一维是 W//2 + 1，利用了共轭对称性
        # fft_x: [B, C, H, W_freq] (复数)
        fft_x = torch.fft.rfft2(x, norm='ortho')

        # 3. 计算动态频域注意力
        # att_weight: [B, C, 1, 1] (复数)
        att_weight = self.freq_att(fft_x)

        # 4. 频谱调制
        # 频域特征 * 动态权重
        # 相当于在空域做了一个全局的、动态的自适应滤波
        spectral_modulated = fft_x * att_weight

        # 5. 傅里叶逆变换 (IFFT)
        # 变回空域特征
        # 显式指定 s=(H, W) 确保输出尺寸与输入一致
        out = torch.fft.irfft2(spectral_modulated, s=(H, W), norm='ortho')

        out = self.bn(out)
        out = self.act(out)

        # 7. 残差连接
        if self.in_channels != self.out_channels:
            # 使用 conv1x1 调整 shortcut 的通道数
            shortcut = self.conv1x1(shortcut)

        return out + shortcut


if __name__ == '__main__':
    # 模拟一个输入：Batch=2, Channel=1024 (Layer 5), H=16, W=16
    x = torch.randn(2, 1024, 16, 16)

    # 实例化模块：输出通道降为 512
    model = SCB(in_channels=1024, out_channels=512)

    # 前向传播
    out = model(x)

    print(f"Input shape: {x.shape}")
    print(f"Output shape: {out.shape}")

