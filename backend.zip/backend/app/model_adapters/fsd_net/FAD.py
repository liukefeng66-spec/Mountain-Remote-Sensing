import torch
import torch.nn as nn
import torch.fft as fft


class ComplexFFT(nn.Module):
    def __init__(self):
        super(ComplexFFT, self).__init__()

    def forward(self, x):
        x_fft = fft.rfft2(x, norm='ortho')
        return x_fft.real, x_fft.imag


class ComplexIFFT(nn.Module):
    def __init__(self):
        super(ComplexIFFT, self).__init__()

    def forward(self, real, imag):
        x_complex = torch.complex(real, imag)
        x_ifft = fft.irfft2(x_complex, norm='ortho')
        return x_ifft


class Stage2_fft_Adapted(nn.Module):

    def __init__(self, dim):
        super(Stage2_fft_Adapted, self).__init__()
        self.c_fft = ComplexFFT()
        # 处理实部和虚部连接后的特征 (dim * 2)
        self.conv1x1 = nn.Conv2d(dim * 2, dim * 2, kernel_size=1)
        self.c_ifft = ComplexIFFT()
        self.bn = nn.BatchNorm2d(dim)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        real, imag = self.c_fft(x)
        # 频域特征交互
        combined = torch.cat([real, imag], dim=1)
        conv_out = self.conv1x1(combined)

        # 拆分回实部虚部
        out_channels = conv_out.shape[1] // 2
        real_out = conv_out[:, :out_channels, :, :]
        imag_out = conv_out[:, out_channels:, :, :]

        # 逆变换回空域
        out = self.c_ifft(real_out, imag_out)

        if out.shape != x.shape:
            out = torch.nn.functional.interpolate(out, size=x.shape[2:], mode='bilinear')

        return self.act(self.bn(out))



class FAD_Block(nn.Module):
    def __init__(self, dim):
        super(FAD_Block, self).__init__()

        # 频域交互分支：用于过滤差异特征中的噪声
        self.freq_filter = Stage2_fft_Adapted(dim)

        # 空间交互分支 (spatial_interaction)：用于生成 Attention Mask
        self.spatial_gate = nn.Sequential(
            nn.Conv2d(dim, dim // 8, kernel_size=1),
            nn.BatchNorm2d(dim // 8),
            nn.ReLU(),
            nn.Conv2d(dim // 8, 1, kernel_size=1),
            nn.Sigmoid()
        )

        # 特征融合层
        self.fusion = nn.Sequential(
            nn.Conv2d(dim * 2, dim, kernel_size=1),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )

    def forward(self, xA, xB):
        # 1. 计算原始差异特征 (Difference)
        x_diff = torch.abs(xA - xB)

        # 2. [频域增强]
        # 这一步能去掉光照不一致导致的全局伪变化
        x_diff_freq = self.freq_filter(x_diff)

        # 3. [特征增强] 将频域清洗后的特征与原始差异结合
        x_enhanced = x_diff + x_diff_freq

        # 4. [空间门控]
        att_map = self.spatial_gate(x_enhanced)

        # 5. 输出加权后的特征
        out = x_enhanced * att_map

        return out