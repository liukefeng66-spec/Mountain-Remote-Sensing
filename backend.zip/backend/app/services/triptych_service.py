﻿from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

def _contain_crop(img: Image.Image, target_size=(720, 720)) -> Image.Image:
    img = img.convert("RGB")
    tw, th = target_size
    iw, ih = img.size
    scale = max(tw / iw, th / ih)
    nw, nh = int(iw * scale), int(ih * scale)
    
    # Check for Pillow version for Resampling
    try:
        resample = Image.Resampling.LANCZOS
    except AttributeError:
        resample = Image.LANCZOS

    img = img.resize((nw, nh), resample)
    left = (nw - tw) // 2
    top = (nh - th) // 2
    return img.crop((left, top, left + tw, top + th))

def _load_font(size=42, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc"
    ]
    for p in candidates:
        if Path(p).exists():
            return ImageFont.truetype(p, size=size)
    return ImageFont.load_default()

def build_triptych(
    image_a_path: str,
    image_b_path: str,
    result_path: str,
    output_path: str,
    caption: str = "西南山地本地化验证效果对比图",
    note: str = "红色/高亮区域为系统检测到的变化",
):
    tile_w, tile_h = 720, 720
    title_h = 88
    caption_h = 150
    gap = 22
    margin = 34
    
    images = [
        _contain_crop(Image.open(image_a_path), (tile_w, tile_h)),
        _contain_crop(Image.open(image_b_path), (tile_w, tile_h)),
        _contain_crop(Image.open(result_path), (tile_w, tile_h)),
    ]
    titles = ["时相A", "时相B", "系统检测结果"]
    
    canvas_w = margin * 2 + tile_w * 3 + gap * 2
    canvas_h = margin + title_h + tile_h + caption_h + margin
    canvas = Image.new("RGB", (canvas_w, canvas_h), "white")
    draw = ImageDraw.Draw(canvas)
    
    title_font = _load_font(38, bold=True)
    caption_font = _load_font(32, bold=True)
    note_font = _load_font(26, bold=False)
    
    accent = (13, 102, 120)
    text_color = (29, 42, 50)
    sub_color = (86, 103, 111)
    
    for i, (img, title) in enumerate(zip(images, titles)):
        x = margin + i * (tile_w + gap)
        y = margin + title_h
        
        # Title
        try:
            bbox = draw.textbbox((0, 0), title, font=title_font)
        except AttributeError:
            w, h = draw.textsize(title, font=title_font)
            bbox = (0, 0, w, h)
            
        tx = x + (tile_w - (bbox[2]-bbox[0])) / 2
        draw.text((tx, margin + 18), title, fill=text_color, font=title_font)
        
        canvas.paste(img, (x, y))
        
        # Border
        draw.rounded_rectangle(
            [x, y, x + tile_w, y + tile_h],
            radius=8, outline=(205, 215, 219), width=4
        )
        
    sep_y = margin + title_h + tile_h + 34
    draw.line((margin, sep_y, canvas_w-margin, sep_y), fill=accent, width=4)
    
    try:
        cb = draw.textbbox((0, 0), caption, font=caption_font)
    except AttributeError:
        cw, ch = draw.textsize(caption, font=caption_font)
        cb = (0, 0, cw, ch)
        
    cx = (canvas_w - (cb[2]-cb[0])) / 2
    draw.text((cx, sep_y + 24), caption, fill=text_color, font=caption_font)
    
    try:
        nb = draw.textbbox((0, 0), note, font=note_font)
    except AttributeError:
        nw, nh = draw.textsize(note, font=note_font)
        nb = (0, 0, nw, nh)
        
    nx = (canvas_w - (nb[2]-nb[0])) / 2
    draw.text((nx, sep_y + 76), note, fill=sub_color, font=note_font)
    
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_path, quality=95)
    return output_path