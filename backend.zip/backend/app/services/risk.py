﻿from math import log

CONFIG = {
    "weights": {
        "slope": 0.30,
        "relief": 0.20,
        "road": 0.15,
        "vegetation": 0.15,
        "lithology": 0.10,
        "landuse": 0.10
    },
    "normalization": {
        "slope_deg": [5, 45],
        "relief_m": [0, 80],
        "road_distance_m": [0, 1500],
        "ndvi": [0.1, 0.8]
    },
    "rainfall_decay_k": 0.84
}

def clip(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(v)))

def norm(x, lo, hi):
    if x is None:
        return 0.5
    return clip((float(x) - lo) / (hi - lo))

def effective_rainfall(last6, k=0.84):
    vals = list(last6 or [])[:6]
    return sum((k ** (i + 1)) * float(r) for i, r in enumerate(vals))

def static_assessment(data):
    veg = clip(float(data.veg_degradation if data.veg_degradation is not None else 0.5))
    complexity = norm(float(data.boundary_complexity if data.boundary_complexity is not None else 2.0), 1.0, 5.0)
    texture = clip(float(data.texture_variance if data.texture_variance is not None else 0.5))
    area = norm(float(data.area_px if data.area_px is not None else 5000), 0, 20000)
    
    landform_map = {"高山峡谷": 1.0, "中山丘陵": 0.6, "平原盆地": 0.2}
    landform = landform_map.get(data.landform_type, 0.6)
    
    score = (0.25 * veg + 0.25 * complexity + 0.20 * texture + 0.20 * area + 0.10 * landform)
    
    if score >= 0.70: level = "高易发"
    elif score >= 0.45: level = "中易发"
    elif score >= 0.25: level = "低易发"
    else: level = "非/极低易发"
    
    reasons = []
    if veg >= 0.6: reasons.append("可见光植被指数(VARI)显著退化")
    if complexity >= 0.6: reasons.append("图斑边界高度破碎不规则")
    if texture >= 0.6: reasons.append("表面纹理粗糙度剧变")
    if area >= 0.6: reasons.append("地表扰动面积当量极大")
    if landform == 1.0: reasons.append("处于高山峡谷高势能区")
    return round(score, 4), level, reasons

def rainfall_assessment(data):
    rp = effective_rainfall(data.rainfall_last6, CONFIG["rainfall_decay_k"])
    I = float(data.current_intensity_mm_h)
    D = float(data.duration_h)
    F = float(data.forecast_24h_mm)
    
    trigger = I * max(D, 1.0)
    dynamic_index = trigger + 0.45 * rp + 0.35 * F
    
    if dynamic_index >= 140 or (I >= 50 and D >= 3): level = "红色"
    elif dynamic_index >= 90 or (I >= 30 and D >= 2): level = "橙色"
    elif dynamic_index >= 45: level = "黄色"
    else: level = "无/蓝色"
    return round(rp, 2), level, round(dynamic_index, 2)

def combine(static_level, rainfall_level):
    if static_level == "高易发" and rainfall_level == "红色": return "极高", 0.90, "立即核查"
    if static_level == "高易发" and rainfall_level in ["橙色", "黄色"]: return "高", 0.78, "优先核查"
    if static_level == "中易发" and rainfall_level == "红色": return "高", 0.75, "优先核查"
    if static_level == "中易发" and rainfall_level in ["橙色", "黄色"]: return "中", 0.55, "常规核查"
    if static_level in ["低易发", "非/极低易发"]: return "低", 0.25, "暂不优先核查"
    return "中", 0.50, "常规核查"

def evaluate_patch(req):
    static_score, static_level, reasons = static_assessment(req)
    rp, rain_level, dynamic_index = rainfall_assessment(req)
    overall_level, overall_score, action = combine(static_level, rain_level)
    
    if rain_level in ["红色", "橙色"]: reasons.append(f"动态降雨达到{rain_level}预警等级")
    if rp >= 40: reasons.append("前期有效降雨偏高")
    if req.forecast_24h_mm >= 40: reasons.append("未来24小时仍有较强降雨")
    
    return {
        "static_score": static_score,
        "susceptibility_level": static_level,
        "susceptibility_score": static_score,
        "effective_rainfall_mm": rp,
        "antecedent_rain": rp,
        "rainfall_level": rain_level,
        "warning": rain_level,
        "dynamic_index": dynamic_index,
        "overall_score": overall_score,
        "risk_level": overall_level,
        "action": action,
        "reasons": reasons if reasons else ["暂无显著高风险环境因子"],
        "disclaimer": "基于图像形态学的无底图轻量化评估方案。动态降雨阈值需进行本地化标定。"
    }
