﻿import cv2
import numpy as np
import math
from shapely.geometry import Polygon, mapping
from rasterio.transform import xy

def pixel_to_world(transform, px, py):
    if transform is None: return float(px), float(py)
    x, y = xy(transform, py, px, offset="center")
    return float(x), float(y)

def get_vari(img):
    # img is RGB (H, W, 3) float array
    img = img.astype(np.float32)
    R = img[:, :, 0]
    G = img[:, :, 1]
    B = img[:, :, 2]
    denom = G + R - B
    denom[denom == 0] = 1e-6
    return (G - R) / denom

def vectorize_binary(binary, im1=None, im2=None, georef=None, min_area_px=20):
    contours, _ = cv2.findContours((binary>0).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    features, stats = [], []
    transform = georef.get("transform") if georef else None
    
    for i, c in enumerate(contours, start=1):
        area_px = cv2.contourArea(c)
        if area_px < min_area_px: continue
        perimeter_px = cv2.arcLength(c, True)
        
        m = cv2.moments(c)
        cx = m["m10"]/m["m00"] if m["m00"] else 0
        cy = m["m01"]/m["m00"] if m["m00"] else 0
        
        pts = [pixel_to_world(transform, int(p[0][0]), int(p[0][1])) for p in c]
        if len(pts) < 3: continue
        poly = Polygon(pts)
        if not poly.is_valid: poly = poly.buffer(0)
        
        wx, wy = pixel_to_world(transform, cx, cy)
        
        # Calculate Image Morphological Features
        complexity = (perimeter_px ** 2) / (4 * math.pi * area_px) if area_px > 0 else 1.0
        
        veg_deg, texture_var = 0.0, 0.0
        if im1 is not None and im2 is not None:
            x, y, w, h = cv2.boundingRect(c)
            # Create a mask for just this patch
            mask_roi = np.zeros((h, w), dtype=np.uint8)
            cv2.drawContours(mask_roi, [c], -1, 255, -1, offset=(-x, -y))
            
            if cv2.countNonZero(mask_roi) > 0:
                t1_roi = im1[y:y+h, x:x+w]
                t2_roi = im2[y:y+h, x:x+w]
                
                # Vegetation Degradation (VARI difference)
                vari1 = get_vari(t1_roi)
                vari2 = get_vari(t2_roi)
                mean_v1 = cv2.mean(vari1, mask=mask_roi)[0]
                mean_v2 = cv2.mean(vari2, mask=mask_roi)[0]
                veg_deg = max(0.0, float(mean_v1 - mean_v2)) # Only care if vegetation decreased
                
                # Texture Roughness (StdDev of grayscale T2 inside mask)
                gray2 = cv2.cvtColor(t2_roi, cv2.COLOR_RGB2GRAY)
                mean_val, stddev = cv2.meanStdDev(gray2, mask=mask_roi)
                texture_var = float(stddev[0][0]) / 255.0
                
        props = {
            "patch_id": f"P{i:04d}", 
            "area_px": float(area_px), 
            "perimeter_px": float(perimeter_px),
            "centroid_x": wx, 
            "centroid_y": wy,
            "boundary_complexity": round(complexity, 3),
            "veg_degradation": round(veg_deg, 3),
            "texture_variance": round(texture_var, 3)
        }
        features.append({"type":"Feature", "geometry":mapping(poly), "properties":props})
        stats.append(props)
        
    return {"type":"FeatureCollection", "features":features}, stats