import json, shutil
from pathlib import Path
import pandas as pd
import geopandas as gpd
from shapely.geometry import shape
def export_geojson(fc, path):
    Path(path).write_text(json.dumps(fc, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
def export_csv(stats, path):
    pd.DataFrame(stats).to_csv(path, index=False, encoding="utf-8-sig")
    return path
def export_shapefile_zip(fc, out_dir, base="patches"):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    geoms = [shape(f["geometry"]) for f in fc["features"]]
    props = [f["properties"] for f in fc["features"]]
    gdf = gpd.GeoDataFrame(props, geometry=geoms)
    shp_dir = out_dir / base
    shp_dir.mkdir(exist_ok=True)
    shp = shp_dir / f"{base}.shp"
    gdf.to_file(shp, driver="ESRI Shapefile", encoding="utf-8")
    archive = shutil.make_archive(str(out_dir / base), "zip", shp_dir)
    return archive