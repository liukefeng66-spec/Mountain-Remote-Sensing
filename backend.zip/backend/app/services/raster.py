from pathlib import Path
import numpy as np
from PIL import Image
import rasterio
def read_image(path: str):
    p = Path(path)
    georef = None
    if p.suffix.lower() in {".tif", ".tiff"}:
        with rasterio.open(p) as src:
            arr = src.read()
            georef = {"transform": src.transform, "crs": src.crs, "width": src.width, "height": src.height}
        if arr.shape[0] >= 3:
            arr = np.moveaxis(arr[:3], 0, -1)
        else:
            arr = np.repeat(arr[0][..., None], 3, axis=-1)
        arr = arr.astype(np.float32)
        lo, hi = np.percentile(arr, (2, 98))
        arr = np.clip((arr - lo) / max(hi-lo, 1e-6), 0, 1)
        arr = (arr * 255).astype(np.uint8)
    else:
        arr = np.array(Image.open(p).convert("RGB"))
    return arr, georef
def save_gray(arr, path):
    arr = np.asarray(arr)
    if arr.dtype != np.uint8:
        arr = np.clip(arr * 255 if arr.max() <= 1.0 else arr, 0, 255).astype(np.uint8)
    Image.fromarray(arr).save(path)
def iter_tiles(img, tile_size=512, overlap=64):
    h, w = img.shape[:2]
    step = tile_size - overlap
    ys = list(range(0, max(h - tile_size, 0) + 1, step))
    xs = list(range(0, max(w - tile_size, 0) + 1, step))
    if not ys or ys[-1] != max(h - tile_size, 0): ys.append(max(h - tile_size, 0))
    if not xs or xs[-1] != max(w - tile_size, 0): xs.append(max(w - tile_size, 0))
    for y in sorted(set(ys)):
        for x in sorted(set(xs)):
            tile = img[y:y+tile_size, x:x+tile_size]
            pad_h, pad_w = tile_size-tile.shape[0], tile_size-tile.shape[1]
            if pad_h or pad_w:
                tile = np.pad(tile, ((0,pad_h),(0,pad_w),(0,0)), mode="reflect")
            yield x, y, tile
def merge_tiles(tile_outputs, out_shape, tile_size=512):
    h, w = out_shape
    canvas = np.zeros((h, w), np.float32)
    weight = np.zeros((h, w), np.float32)
    for x, y, pred in tile_outputs:
        ph, pw = min(tile_size, h-y), min(tile_size, w-x)
        canvas[y:y+ph, x:x+pw] += pred[:ph, :pw]
        weight[y:y+ph, x:x+pw] += 1
    return canvas / np.maximum(weight, 1)