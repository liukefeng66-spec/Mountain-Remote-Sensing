import torch
torch.set_num_threads(1)
from pathlib import Path
import cv2
import numpy as np
from ..config import TILE_SIZE, TILE_OVERLAP, DEFAULT_THRESHOLD, RESULT_DIR, MODEL_DIR
from ..model_adapters.tidal import TIDALAdapter
from ..model_adapters.fsd import FSDAdapter
from .raster import iter_tiles, merge_tiles, save_gray

_MODELS = {}
def get_model(name):
    name = name.lower()
    if name not in _MODELS:
        if name == "tidal": _MODELS[name] = TIDALAdapter(str(MODEL_DIR / "tidal.pth"))
        elif name == "fsd": _MODELS[name] = FSDAdapter(str(MODEL_DIR / "fsd.pth"))
        else: raise ValueError(f"unknown model: {name}")
    return _MODELS[name]

def infer_large(t1, t2, model_name, threshold=DEFAULT_THRESHOLD):
    if t1.shape[:2] != t2.shape[:2]:
        raise ValueError("T1 and T2 sizes do not match")
    model = get_model(model_name)
    h, w = t1.shape[:2]
    outs = []
    tiles2 = {(x,y):tile for x,y,tile in iter_tiles(t2, TILE_SIZE, TILE_OVERLAP)}
    for x, y, tile1 in iter_tiles(t1, TILE_SIZE, TILE_OVERLAP):
        pred = model.predict(tile1, tiles2[(x,y)])
        if pred.shape != (TILE_SIZE, TILE_SIZE):
            pred = cv2.resize(pred.astype(np.float32), (TILE_SIZE,TILE_SIZE), interpolation=cv2.INTER_LINEAR)
        outs.append((x,y,pred.astype(np.float32)))
    prob = merge_tiles(outs, (h,w), TILE_SIZE)
    binary = (prob >= threshold).astype(np.uint8) * 255
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((3,3),np.uint8))
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, np.ones((5,5),np.uint8))
    
    print("="*40)
    print(f"[DEBUG] Model: {model_name}")
    print(f"[DEBUG] Max: {prob.max():.4f}, Min: {prob.min():.4f}, Mean: {prob.mean():.4f}")
    print(f"[DEBUG] Positive ratio ({threshold}): {(binary > 0).mean() * 100:.2f}%")
    print("="*40)
    
    return prob, binary

def save_prediction(job_dir: Path, model_name, prob, binary):
    job_dir.mkdir(parents=True, exist_ok=True)
    prob_path = job_dir / f"{model_name}_prob.png"
    bin_path = job_dir / f"{model_name}_binary.png"
    save_gray(prob, prob_path)
    save_gray(binary, bin_path)
    return prob_path, bin_path

def make_overlay(image_b_path, binary_mask_path, output_path):
    import cv2
    import numpy as np
    from .raster import read_image
    img, _ = read_image(str(image_b_path))
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    mask = cv2.imread(str(binary_mask_path), cv2.IMREAD_GRAYSCALE)
    if img is None or mask is None:
        raise ValueError("Failed to read image or mask")
    if mask.shape[:2] != img.shape[:2]:
        mask = cv2.resize(mask, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST)
    changed = mask > 127
    overlay = img.copy()
    if changed.any():
        red_layer = np.zeros_like(img)
        red_layer[:, :] = (0, 0, 255)
        overlay[changed] = cv2.addWeighted(
            img[changed], 0.45,
            red_layer[changed], 0.55,
            0
        )
    cv2.imwrite(str(output_path), overlay)
    return str(output_path)
