from pathlib import Path
from uuid import uuid4
import json, shutil
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel
from ..config import UPLOAD_DIR, RESULT_DIR, EXPORT_DIR, ALLOWED_EXTENSIONS
from ..services.raster import read_image
from ..services.inference import infer_large, save_prediction, make_overlay
from ..services.vectorize import vectorize_binary
from ..services.export import export_geojson, export_csv, export_shapefile_zip
from ..services.risk import evaluate_patch
from ..db import add_task, list_tasks, get_task_summary, get_task, update_task_status, save_task_feedback

router = APIRouter(prefix="/api")

JOBS = {}

def _save_upload(f: UploadFile, job_dir: Path, label: str):
    ext = Path(f.filename or "").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS: raise HTTPException(400, f"{label} 文件格式不支持")
    p = job_dir / f"{label}{ext}"
    with p.open("wb") as out: shutil.copyfileobj(f.file, out)
    return p

@router.get("/health")
def health(): return {"status":"ok"}

@router.post("/detect")
async def detect(t1: UploadFile=File(...), t2: UploadFile=File(...), model: str=Form("dual"), threshold: float=Form(0.5), alpha: float=Form(0.5)):
    if model not in {"tidal","fsd","dual","both"}: raise HTTPException(400,"model 必须为 tidal/fsd/dual/both")
    job_id = uuid4().hex[:12]; upload_dir=UPLOAD_DIR/job_id; result_dir=RESULT_DIR/job_id
    upload_dir.mkdir(parents=True, exist_ok=True); result_dir.mkdir(parents=True, exist_ok=True)
    p1,p2=_save_upload(t1,upload_dir,"t1"),_save_upload(t2,upload_dir,"t2")
    im1,g1=read_image(str(p1)); im2,g2=read_image(str(p2))
    if im1.shape[:2] != im2.shape[:2]: raise HTTPException(400,"T1/T2 尺寸不一致，请先配准")
    
    output={}
    if model == "dual":
        import cv2
        import numpy as np
        prob_tidal, bin_tidal = infer_large(im1, im2, "tidal", threshold)
        prob_fsd, bin_fsd = infer_large(im1, im2, "fsd", threshold)
        
        # 决策级融合 (Decision-level fusion)
        fused_prob = alpha * prob_tidal + (1.0 - alpha) * prob_fsd
        fused_binary = (fused_prob >= threshold).astype(np.uint8) * 255
        fused_binary = cv2.morphologyEx(fused_binary, cv2.MORPH_OPEN, np.ones((3,3),np.uint8))
        fused_binary = cv2.morphologyEx(fused_binary, cv2.MORPH_CLOSE, np.ones((5,5),np.uint8))
        
        # 保存各分支概率图供解释
        prob_p_tidal, _ = save_prediction(result_dir, "tidal", prob_tidal, bin_tidal)
        prob_p_fsd, _ = save_prediction(result_dir, "fsd", prob_fsd, bin_fsd)
        
        # 保存融合结果并进行后续业务解析
        prob_p, bin_p = save_prediction(result_dir, "dual", fused_prob, fused_binary)
        overlay_p = result_dir / "dual_overlay.png"
        make_overlay(p2, bin_p, overlay_p)
        
        fc, stats = vectorize_binary(fused_binary, im1, im2, g1)
        geo_p = result_dir / "dual_patches.geojson"
        csv_p = result_dir / "dual_stats.csv"
        export_geojson(fc, geo_p); export_csv(stats, csv_p)
        
        output["dual"] = {
            "tidal_prob_url": f"/files/results/{job_id}/{prob_p_tidal.name}",
            "fsd_prob_url": f"/files/results/{job_id}/{prob_p_fsd.name}",
            "fused_prob_url": f"/files/results/{job_id}/{prob_p.name}",
            "fused_binary_url": f"/files/results/{job_id}/{bin_p.name}",
            "overlay_url": f"/files/results/{job_id}/{overlay_p.name}",
            "geojson_url": f"/files/results/{job_id}/{geo_p.name}",
            "stats_url": f"/files/results/{job_id}/{csv_p.name}",
            "patch_count": len(stats),
            "total_area_px": round(sum(x["area_px"] for x in stats), 2) if stats else 0,
            "stats": stats,
            "image_a_url": f"/files/uploads/{job_id}/{p1.name}",
            "image_b_url": f"/files/uploads/{job_id}/{p2.name}",
            "image_a_path": str(p1),
            "image_b_path": str(p2),
            "overlay_path": str(overlay_p)
        }
    else:
        models=["tidal","fsd"] if model=="both" else [model]
        for m in models:
            prob,binary=infer_large(im1,im2,m,threshold)
            prob_p,bin_p=save_prediction(result_dir,m,prob,binary)
            overlay_p = result_dir / f"{m}_overlay.png"
            make_overlay(p2, bin_p, overlay_p)
            fc,stats=vectorize_binary(binary, im1, im2, g1)
            geo_p=result_dir/f"{m}_patches.geojson"; csv_p=result_dir/f"{m}_stats.csv"
            export_geojson(fc,geo_p); export_csv(stats,csv_p)
            output[m]={
                "prob_url":f"/files/results/{job_id}/{prob_p.name}",
                "binary_url":f"/files/results/{job_id}/{bin_p.name}",
                "overlay_url":f"/files/results/{job_id}/{overlay_p.name}",
                "geojson_url":f"/files/results/{job_id}/{geo_p.name}",
                "stats_url":f"/files/results/{job_id}/{csv_p.name}",
                "patch_count":len(stats),
                "total_area_px":round(sum(x["area_px"] for x in stats),2) if stats else 0,
                "stats":stats,
                "image_a_url": f"/files/uploads/{job_id}/{p1.name}",
                "image_b_url": f"/files/uploads/{job_id}/{p2.name}",
                "image_a_path": str(p1),
                "image_b_path": str(p2),
                "overlay_path": str(overlay_p)
            }
    
    JOBS[job_id]={"t1":str(p1),"t2":str(p2),"outputs":output}
    return {"job_id":job_id,"width":im1.shape[1],"height":im1.shape[0],"outputs":output}

class RiskRequest(BaseModel):
    job_id: str
    patch_id: str
    
    veg_degradation: float | None = None
    boundary_complexity: float | None = None
    texture_variance: float | None = None
    area_px: float | None = None
    landform_type: str = "中山丘陵"
    
    rainfall_last6: list[float] = []
    current_intensity_mm_h: float = 0
    duration_h: float = 0
    forecast_24h_mm: float = 0
    
    centroid_x: float | None = None
    centroid_y: float | None = None
    change_type: str = "未分类"

@router.post("/risk/evaluate")
def risk_eval(req: RiskRequest):
    result = evaluate_patch(req)
    if result["risk_level"] in {"高", "极高"}:
        add_task({
            "job_id": req.job_id,
            "patch_id": req.patch_id,
            "risk_level": result["risk_level"],
            "risk_score": result["overall_score"],
            "susceptibility_level": result["susceptibility_level"],
            "rain_level": result["rainfall_level"],
            "risk_reason": result["reasons"],
            "suggestion": result["action"],
            "priority": result["action"],
            "centroid_x": req.centroid_x,
            "centroid_y": req.centroid_y,
            "area": req.area,
            "change_type": req.change_type
        })
    return result

@router.get("/tasks/summary")
def get_summary():
    return get_task_summary()

@router.get("/tasks")
def fetch_tasks(keyword: str="", risk: str="", status: str="", priority: str=""):
    return {"items": list_tasks({"keyword":keyword, "risk":risk, "status":status, "priority":priority})}

@router.get("/tasks/{task_id}")
def fetch_task(task_id: int):
    t = get_task(task_id)
    if not t: raise HTTPException(404, "任务不存在")
    return t

class StatusUpdate(BaseModel):
    status: str

@router.patch("/tasks/{task_id}/status")
def update_status(task_id: int, body: StatusUpdate):
    update_task_status(task_id, body.status)
    return {"ok": True}

@router.post("/tasks/{task_id}/feedback")
async def submit_feedback(task_id: int, result: str = Form(...), description: str = Form(""), photo: UploadFile = File(None)):
    if result not in {"确认变化", "误报", "需复核"}: raise HTTPException(400, "非法结果")
    photo_path = ""
    if photo:
        p = UPLOAD_DIR / "feedback" / str(task_id) / photo.filename
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "wb") as f: f.write(await photo.read())
        photo_path = f"/files/uploads/feedback/{task_id}/{photo.filename}"
    
    new_status = save_task_feedback(task_id, result, description, photo_path)
    return {"message": "保存成功", "status": new_status, "photo_path": photo_path}

@router.get("/tasks/export/excel")
def tasks_export():
    import pandas as pd
    items = list_tasks()
    p = EXPORT_DIR / "inspection_tasks.xlsx"
    pd.DataFrame(items).to_excel(p, index=False)
    return FileResponse(p, filename=p.name)

# --- Feedback Management Endpoints ---
from ..db import get_feedback_summary, add_feedback_sample, list_feedbacks, update_feedback_review

@router.get("/feedback/summary")
def get_fb_summary():
    return get_feedback_summary()

@router.get("/feedback/task-options")
def get_task_options():
    tasks = list_tasks()
    return [{"id":t['id'], "task_code":t['task_code'], "patch_code":t['patch_code'], 
             "change_type":t['change_type'], "risk_level":t['risk_level'], 
             "source_model":t.get("source_model","TIDAL-Net"), "status":t['status']} for t in tasks[:100]]

@router.post("/feedback")
async def create_fb(task_id: int = Form(...), feedback_type: str = Form(...), note: str = Form(""), site_photo: UploadFile = File(None), annotation: UploadFile = File(None)):
    task = get_task(task_id)
    if not task: raise HTTPException(404, "任务不存在")
    if feedback_type not in ["误报", "漏报", "确认正确", "需复核"]: raise HTTPException(400, "非法类型")
    
    photo_path, ann_path = "", ""
    base_dir = UPLOAD_DIR / "feedback_samples" / str(task_id)
    base_dir.mkdir(parents=True, exist_ok=True)
    if site_photo:
        p = base_dir / site_photo.filename
        with open(p, "wb") as f: f.write(await site_photo.read())
        photo_path = f"/files/uploads/feedback_samples/{task_id}/{site_photo.filename}"
    if annotation:
        p = base_dir / annotation.filename
        with open(p, "wb") as f: f.write(await annotation.read())
        ann_path = f"/files/uploads/feedback_samples/{task_id}/{annotation.filename}"
    
    code = add_feedback_sample(task, feedback_type, note, photo_path, ann_path)
    if not code: raise HTTPException(409, "该任务已存在同类型有效反馈")
    
    # Auto-update task status if it's the first time being fed back
    if task['status'] not in ["已核查", "需复核"]:
        new_status = "需复核" if feedback_type == "需复核" else "已核查"
        save_task_feedback(task_id, feedback_type, note, photo_path)
    
    return {"message": "保存成功", "code": code}

@router.get("/feedback")
def fetch_feedbacks(feedback_type: str="", review_status: str="", keyword: str=""):
    return list_feedbacks({"feedback_type":feedback_type, "review_status":review_status, "keyword":keyword})

class ReviewUpdate(BaseModel):
    review_status: str

@router.patch("/feedback/{fb_id}/review")
def update_fb_review(fb_id: int, body: ReviewUpdate):
    if body.review_status not in ["待审核", "已确认", "已作废"]: raise HTTPException(400, "非法状态")
    update_feedback_review(fb_id, body.review_status)
    return {"ok": True}

@router.get("/feedback/export/excel")
def feedback_export():
    import pandas as pd
    items = list_feedbacks({"review_status":"已确认"})
    p = EXPORT_DIR / "feedback_samples.xlsx"
    pd.DataFrame(items).to_excel(p, index=False)
    return FileResponse(p, filename=p.name)
