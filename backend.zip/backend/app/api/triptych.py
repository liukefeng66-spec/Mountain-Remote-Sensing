﻿from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Form, HTTPException
from fastapi.responses import FileResponse
from ..services.triptych_service import build_triptych
from ..config import RESULT_DIR

router = APIRouter(prefix="/triptych", tags=["triptych"])
TRIPTYCH_DIR = RESULT_DIR / "triptych"
TRIPTYCH_DIR.mkdir(parents=True, exist_ok=True)

def _safe_existing_path(path_str: str) -> Path:
    p = Path(path_str).resolve()
    if not p.exists() or not p.is_file():
        raise HTTPException(status_code=404, detail=f"文件不存在: {path_str}")
    return p

@router.post("/generate")
def generate_triptych(
    image_a_path: str = Form(...),
    image_b_path: str = Form(...),
    result_path: str = Form(...),
    caption: str = Form("西南山地本地化验证效果对比图"),
    note: str = Form("红色/高亮区域为系统检测到的变化"),
):
    image_a = _safe_existing_path(image_a_path)
    image_b = _safe_existing_path(image_b_path)
    result = _safe_existing_path(result_path)
    
    filename = f"triptych_{uuid4().hex[:10]}.png"
    out_path = TRIPTYCH_DIR / filename
    
    build_triptych(
        str(image_a), str(image_b), str(result), str(out_path),
        caption=caption, note=note
    )
    
    return {
        "success": True,
        "filename": filename,
        "preview_url": f"/api/triptych/file/{filename}",
        "download_url": f"/api/triptych/file/{filename}?download=1",
    }

@router.get("/file/{filename}")
def get_triptych(filename: str, download: int = 0):
    path = TRIPTYCH_DIR / Path(filename).name
    if not path.exists():
        raise HTTPException(status_code=404, detail="三联图不存在")
    return FileResponse(
        path,
        media_type="image/png",
        filename=path.name if download else None,
        content_disposition_type="attachment" if download else "inline",
    )