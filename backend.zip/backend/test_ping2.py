﻿import requests
import json
url = 'http://127.0.0.1:8080/api/detect'
files = {
    't1': ('t1.jpg', open('data/uploads/799d0c06b0d4/t1.png', 'rb'), 'image/jpeg'),
    't2': ('t2.jpg', open('data/uploads/799d0c06b0d4/t2.png', 'rb'), 'image/jpeg')
}
data = {
    'model': 'tidal',
    'threshold': 0.5
}
try:
    print("Requesting...")
    resp = requests.post(url, files=files, data=data, timeout=10)
    print("Status:", resp.status_code)
except Exception as e:
    print("Exception:", e)