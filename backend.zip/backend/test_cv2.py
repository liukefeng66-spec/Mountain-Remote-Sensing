﻿import cv2
import numpy as np

img = np.zeros((10, 10, 3), dtype=np.uint8)
changed = np.zeros((10, 10), dtype=bool) # All False
red_layer = np.zeros((10, 10, 3), dtype=np.uint8)

try:
    res = cv2.addWeighted(img[changed], 0.45, red_layer[changed], 0.55, 0)
    print("Success:", res.shape)
except Exception as e:
    print("Error:", type(e), e)