﻿import requests
import json
url = 'http://127.0.0.1:8000/api/detect'
files = {
    't1': ('t1.jpg', open('E:/PycharmProjects/website/backend/data/uploads/21f4da19eca9/t1.jpg', 'rb'), 'image/jpeg'),
    't2': ('t2.jpg', open('E:/PycharmProjects/website/backend/data/uploads/21f4da19eca9/t2.jpg', 'rb'), 'image/jpeg')
}
data = {
    'model': 'tidal',
    'threshold': 0.5
}
try:
    print("Requesting 8000...")
    resp = requests.post(url, files=files, data=data, timeout=5)
    print("Status:", resp.status_code)
except Exception as e:
    print("Exception:", type(e), e)