﻿import requests

url = 'http://127.0.0.1:8000/api/detect'

try:
    import os
    import glob
    
    # find the latest upload dir
    upload_dirs = glob.glob('E:/PycharmProjects/website/backend/data/uploads/*')
    upload_dirs.sort(key=os.path.getmtime, reverse=True)
    latest_dir = upload_dirs[0]
    
    t1_path = os.path.join(latest_dir, 't1.jpg')
    t2_path = os.path.join(latest_dir, 't2.jpg')
    
    print(f"Using files: {t1_path}, {t2_path}")
    
    files = {
        't1': ('t1.jpg', open(t1_path, 'rb'), 'image/jpeg'),
        't2': ('t2.jpg', open(t2_path, 'rb'), 'image/jpeg')
    }
    data = {
        'model': 'tidal',
        'threshold': 0.5
    }

    print("Requesting 8000...")
    resp = requests.post(url, files=files, data=data, timeout=10)
    print("Status:", resp.status_code)
    print("Response:", resp.text)
except Exception as e:
    print("Exception:", type(e), e)