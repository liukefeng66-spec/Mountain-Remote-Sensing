﻿import time
import numpy as np
import cv2
from app.services.raster import read_image
from app.services.inference import infer_large
from app.services.vectorize import vectorize_binary

im1, _ = read_image('data/uploads/799d0c06b0d4/t1.png')
im2, _ = read_image('data/uploads/799d0c06b0d4/t2.png')

print('Starting infer_large (fsd)...')
start = time.time()
prob, binary = infer_large(im1, im2, 'fsd', 0.5)
print(f'infer_large took {time.time()-start:.2f} seconds')

print('Starting vectorize_binary...')
start = time.time()
fc, stats = vectorize_binary(binary, im1, im2)
print(f'vectorize_binary took {time.time()-start:.2f} seconds. Patches: {len(stats)}')