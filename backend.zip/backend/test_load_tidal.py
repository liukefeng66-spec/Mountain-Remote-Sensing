﻿import torch
import torch.nn as nn
from app.model_adapters.tidal_net import SRCNet

print('Loading newly trained TIDAL weights...')
model = SRCNet()
ckpt = torch.load('weights/tidal.pth', map_location='cpu')
state_dict = ckpt.get('state_dict', ckpt)

has_ddem3 = any('ddem3' in k or 'sca3' in k for k in state_dict.keys())
print('Has ddem3?', has_ddem3)

if not has_ddem3:
    class DummyDDEM(nn.Module):
        def forward(self, a, b): return a, b
    model.PE.ddem3 = DummyDDEM()

mapped_state_dict = {
    k.replace('.sca1', '.ddem1').replace('.sca2', '.ddem2').replace('.sca3', '.ddem3').replace('.SPA.', '.TIAM.'): v 
    for k, v in state_dict.items()
}

# we must use strict=False because ddem3 is now a DummyDDEM with no weights, but the state_dict obviously has no ddem3 weights anyway.
# wait, if mapped_state_dict has no ddem3, and model.PE.ddem3 has no parameters, strict=True might actually work! Let's test strict=False just to be safe.
res = model.load_state_dict(mapped_state_dict, strict=False)
print('Result:', res)

# test forward pass
print('Testing forward pass...')
a = torch.randn(1, 3, 256, 256)
b = torch.randn(1, 3, 256, 256)
out = model(a, b)
print('Forward pass successful! Output shape:', out[0][0].shape)
