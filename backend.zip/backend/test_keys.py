import torch
from app.model_adapters.tidal_net import SRCNet
model=SRCNet()
ckpt=torch.load('weights/tidal.pth', map_location='cpu')
sd=ckpt.get('state_dict', ckpt)
sd2 = {k.replace('.sca1', '.ddem1').replace('.sca2', '.ddem2').replace('.SPA.', '.TIAM.'): v for k, v in sd.items()}
missing, unexpected = model.load_state_dict(sd2, strict=False)
print('Missing:', missing)
