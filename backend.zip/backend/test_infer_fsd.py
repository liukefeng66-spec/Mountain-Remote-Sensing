﻿import numpy as np
import torch
import cv2
from app.services.inference import infer_large

print('Testing infer_large...')
t1 = np.zeros((1024, 1024, 3), dtype=np.uint8)
t2 = np.zeros((1024, 1024, 3), dtype=np.uint8)

prob, binary = infer_large(t1, t2, 'fsd', 0.5)
print('Done. Prob shape:', prob.shape)