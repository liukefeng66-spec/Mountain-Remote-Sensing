<template>
  <el-card class="triptych-card" shadow="never">
    <template #header>
      <div class="header-row">
        <div>
          <div class="title">本地化验证三联图</div>
          <div class="subtitle">时相A · 时相B · 系统检测结果</div>
        </div>
      </div>
    </template>



    <div class="three-grid">
      <div class="panel">
        <div class="panel-label">时相A</div>
        <el-image :src="imageAUrl" fit="cover" :preview-src-list="[imageAUrl]" />
      </div>
      <div class="panel">
        <div class="panel-label">时相B</div>
        <el-image :src="imageBUrl" fit="cover" :preview-src-list="[imageBUrl]" />
      </div>
      <div class="panel result-panel">
        <div class="panel-label">系统检测结果</div>
        <el-image :src="resultUrl" fit="cover" :preview-src-list="[resultUrl]" />
      </div>
    </div>

    <el-divider />

    <el-form label-width="90px">
      <el-form-item label="图注">
        <el-input v-model="caption" maxlength="60" show-word-limit />
      </el-form-item>
      <el-form-item label="说明">
        <el-input v-model="note" maxlength="80" show-word-limit />
      </el-form-item>
    </el-form>

    <div class="actions">
      <el-button
        type="primary"
        :loading="loading"
        :disabled="!ready"
        @click="handleGenerate"
      >
        生成高清三联图
      </el-button>
      <el-button
        v-if="triptychDownloadUrl"
        type="success"
        @click="downloadTriptych"
      >
        下载 PNG
      </el-button>
    </div>

    <div v-if="triptychPreviewUrl" class="final-preview">
      <div class="final-title">生成结果预览</div>
      <el-image
        :src="triptychPreviewUrl"
        fit="contain"
        :preview-src-list="[triptychPreviewUrl]"
      />
    </div>
  </el-card>
</template>

<script setup>
import { computed, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { generateTriptych } from '../api/triptych'

const props = defineProps({
  imageAUrl: { type: String, default: '' },
  imageBUrl: { type: String, default: '' },
  resultUrl: { type: String, default: '' },
  imageAPath: { type: String, default: '' },
  imageBPath: { type: String, default: '' },
  resultPath: { type: String, default: '' },
})

const caption = ref('西南山地本地化验证效果对比图')
const note = ref('红色/高亮区域为系统检测到的变化')
const loading = ref(false)
const triptychPreviewUrl = ref('')
const triptychDownloadUrl = ref('')

const ready = computed(() =>
  props.imageAPath && props.imageBPath && props.resultPath
)

async function handleGenerate() {
  try {
    loading.value = true
    const data = await generateTriptych({
      imageAPath: props.imageAPath,
      imageBPath: props.imageBPath,
      resultPath: props.resultPath,
      caption: caption.value,
      note: note.value,
    })
    
    const ts = Date.now()
    triptychPreviewUrl.value = data.preview_url + '&t=' + ts
    triptychDownloadUrl.value = data.download_url
    
    ElMessage.success('三联图生成成功')
  } catch (e) {
    console.error(e)
    ElMessage.error(e?.response?.data?.detail || '三联图生成失败')
  } finally {
    loading.value = false
  }
}

function downloadTriptych() {
  window.open(triptychDownloadUrl.value, '_blank')
}
</script>

<style scoped>
.triptych-card {
  margin-top: 18px;
  border-radius: 16px;
}
.header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.title {
  font-size: 18px;
  font-weight: 700;
  color: #18323a;
}
.subtitle {
  margin-top: 4px;
  color: #7a8b91;
  font-size: 13px;
}
.mb16 { margin-bottom: 16px; }
.three-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 14px;
}
.panel {
  background: #f7fafb;
  border: 1px solid #dce6e9;
  border-radius: 12px;
  padding: 10px;
}
.panel-label {
  text-align: center;
  font-weight: 700;
  color: #27444d;
  margin-bottom: 8px;
}
.panel :deep(.el-image) {
  width: 100%;
  aspect-ratio: 1 / 1;
  border-radius: 8px;
  overflow: hidden;
  background: #eef3f4;
}
.result-panel {
  border-color: #87c6c9;
  box-shadow: 0 0 0 2px rgba(42, 151, 155, 0.08) inset;
}
.actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
.final-preview {
  margin-top: 18px;
  padding: 14px;
  background: #f6f9fa;
  border-radius: 12px;
}
.final-title {
  font-weight: 700;
  margin-bottom: 10px;
}
.final-preview :deep(.el-image) {
  width: 100%;
  max-height: 520px;
}
@media (max-width: 900px) {
  .three-grid { grid-template-columns: 1fr; }
}
</style>