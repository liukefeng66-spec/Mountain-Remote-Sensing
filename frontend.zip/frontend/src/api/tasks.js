﻿import axios from 'axios'
export const getTaskSummary = () => axios.get('/api/tasks/summary')
export const getTasks = (params) => axios.get('/api/tasks', { params })
export const getTaskDetail = (id) => axios.get('/api/tasks/' + id)
export const updateTaskStatus = (id, status) => axios.patch('/api/tasks/' + id + '/status', { status })
export const submitTaskFeedback = (id, formData) => axios.post('/api/tasks/' + id + '/feedback', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
export const exportTaskExcel = () => axios.get('/api/tasks/export/excel', { responseType: 'blob' })