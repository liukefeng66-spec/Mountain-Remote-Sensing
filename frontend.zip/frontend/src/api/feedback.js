﻿import axios from 'axios'

export const getFeedbackSummary = () => axios.get('/api/feedback/summary')
export const getTaskOptions = () => axios.get('/api/feedback/task-options')
export const getFeedbackList = (params) => axios.get('/api/feedback', { params })
export const createFeedback = (formData) => axios.post('/api/feedback', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
export const updateFeedbackReview = (id, review_status) => axios.patch('/api/feedback/' + id + '/review', { review_status })
export const exportFeedbackExcel = () => axios.get('/api/feedback/export/excel', { responseType: 'blob' })