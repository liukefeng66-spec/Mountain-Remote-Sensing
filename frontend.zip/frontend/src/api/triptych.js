import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || ''

export async function generateTriptych(payload) {
  const form = new FormData()
  form.append('image_a_path', payload.imageAPath)
  form.append('image_b_path', payload.imageBPath)
  form.append('result_path', payload.resultPath)
  form.append('caption', payload.caption)
  form.append('note', payload.note)

  const res = await axios.post(`${API_BASE}/api/triptych/generate`, form)
  return {
    ...res.data,
    preview_url: API_BASE + res.data.preview_url,
    download_url: API_BASE + res.data.download_url,
  }
}