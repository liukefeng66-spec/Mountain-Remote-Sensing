<template>
  <div class="hero">
    <h1>山地慧眼 · 智慧水土</h1>
    <p>面向西南山地乡村的山洪地灾与水保遥感智能监测平台。把论文模型能力转化为“检测—解析—风险—核查”的可演示业务闭环。</p>
    <el-button type="success" size="large" @click="$router.push('/detect')">开始双时相检测</el-button>
  </div>
  <div class="grid">
    <div class="card metric"><span class="muted">核心模型</span><b>2</b><small>TIDAL-Net / FSD-Net</small></div>
    <div class="card metric"><span class="muted">业务主链</span><b>5</b><small>上传·推理·可视化·统计·导出</small></div>
    <div class="card metric"><span class="muted">风险维度</span><b>2</b><small>静态易发性 + 动态降雨</small></div>
    <div class="card metric"><span class="muted">GIS 输出</span><b>3</b><small>GeoJSON / Shapefile / CSV</small></div>
  </div>
  <div class="section-title">技术闭环</div>
  <div class="card">空天地采集 → 双域智能检测 → 图斑业务解析 → 风险动态评估 → 预警决策支持 → 现场核查反馈 → 人工迭代优化</div>
</template>