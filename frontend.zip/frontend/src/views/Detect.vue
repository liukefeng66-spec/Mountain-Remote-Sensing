﻿<script setup>
import {ref, onMounted} from 'vue'; 
import axios from 'axios'; 
import {ElMessage} from 'element-plus';
import TriptychPanel from '../components/TriptychPanel.vue';

const t1=ref(null), t2=ref(null), model=ref('dual'), threshold=ref(0.5), alpha=ref(0.5), loading=ref(false), res=ref(null)
const inferenceTimeMs=ref(0) // 记录推理时间

const pick=(e,k)=>{ if(k===1)t1.value=e.target.files[0]; else t2.value=e.target.files[0] }

onMounted(() => {
  const saved = localStorage.getItem('lastJob');
  if (saved) {
    try { res.value = JSON.parse(saved); } catch(e){}
  }
});

async function run(){
  if(!t1.value||!t2.value)return ElMessage.warning('请先选择 T1 和 T2');
  loading.value=true;
  const fd=new FormData();
  fd.append('t1',t1.value); fd.append('t2',t2.value);
  fd.append('model',model.value); fd.append('threshold',threshold.value);
  if (model.value === 'dual') fd.append('alpha', alpha.value);
  
  try{
    const startTime = Date.now()
    const { data } = await axios.post('/api/detect',fd)
    inferenceTimeMs.value = Date.now() - startTime // 毫秒级端到端计时
    res.value = data
    localStorage.setItem('lastJob',JSON.stringify(res.value));
    ElMessage.success('推理完成')
  }catch(e){
    ElMessage.error(e.response?.data?.detail||e.message)
  }finally{
    loading.value=false
  }
}

function reset() {
  res.value = null;
  t1.value = null;
  t2.value = null;
  inferenceTimeMs.value = 0;
  localStorage.removeItem('lastJob');
  ElMessage.success('界面已清空');
}

function getModelTitle(key) {
  if (key === 'dual') return '空—频双域协同最终融合结果';
  if (key === 'tidal') return 'TIDAL-Net 单独推理结果';
  if (key === 'fsd') return 'FSD-Net 单独推理结果';
  return key.toUpperCase();
}
</script>

<template>
  <div class="detect-page">
    <!-- 1. 顶部控制台 -->
    <el-card class="box-card mb-20" shadow="hover">
      <template #header><div class="card-header"><b>智能检测控制台</b></div></template>
      <div class="toolbar" style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
        <el-radio-group v-model="model" size="large">
          <el-radio-button label="dual">空—频双域协同</el-radio-button>
          <el-radio-button label="both">分离式对比</el-radio-button>
          <el-radio-button label="tidal">仅 TIDAL-Net</el-radio-button>
          <el-radio-button label="fsd">仅 FSD-Net</el-radio-button>
        </el-radio-group>

        <div style="display:flex; align-items:center; gap: 10px; width: 300px;">
          <span style="white-space:nowrap; font-size:14px; font-weight: bold; color:#123c3d">二值化阈值 τ：</span>
          <el-slider v-model="threshold" :min="0.01" :max="0.9" :step="0.01" style="width: 100%"/>
        </div>

        <el-button type="primary" size="large" :loading="loading" @click="run" style="width: 180px; font-weight: bold;">
          开始协同推理
        </el-button>
        <el-button type="info" size="large" plain @click="reset" style="font-weight: bold;">
          清空重置
        </el-button>
      </div>

      <!-- 优化后的上传区 (方便截图1) -->
      <div class="upload-grid" style="margin-top:24px">
        <div class="upload-box">
          <div class="upload-title">时相 A (前置影像)</div>
          <div class="file-btn-wrap">
            <input type="file" class="file-input" @change="e=>pick(e,1)"/>
            <div class="fake-btn" :style="t1 ? 'background-color: #1abc9c;' : ''">
              {{ t1 ? '已选择: ' + t1.name : '选择 T1 影像文件' }}
            </div>
          </div>
        </div>
        <div class="upload-box">
          <div class="upload-title">时相 B (后置影像)</div>
          <div class="file-btn-wrap">
            <input type="file" class="file-input" @change="e=>pick(e,2)"/>
            <div class="fake-btn" :style="t2 ? 'background-color: #1abc9c;' : ''">
              {{ t2 ? '已选择: ' + t2.name : '选择 T2 影像文件' }}
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <template v-if="res">
      <!-- 全局推理统计 -->
      <div v-if="inferenceTimeMs > 0" class="time-banner mb-20">
        <b>系统端到端推理完成！</b>
      </div>

      <div v-for="(o,name) in res.outputs" :key="name">
        <div class="section-title">{{ getModelTitle(name) }}</div>
        
        <!-- 核心出图区 (方便截图2) -->
        <div class="result-grid mb-20">
          <el-card shadow="never" class="img-card">
            <template #header><div class="img-title">最终决策级融合概率图</div></template>
            <img class="result-img" :src="o.fused_prob_url || o.prob_url"/>
          </el-card>
          <el-card shadow="never" class="img-card">
            <template #header><div class="img-title">融合后提取异常图斑 (二值)</div></template>
            <img class="result-img" :src="o.fused_binary_url || o.binary_url"/>
          </el-card>
        </div>
        
        <!-- 三联图 (自动优化过了) -->
        <div class="mb-20">
          <TriptychPanel 
            :image-a-url="o.image_a_url" 
            :image-b-url="o.image_b_url" 
            :result-url="o.overlay_url" 
            :image-a-path="o.image_a_path" 
            :image-b-path="o.image_b_path" 
            :result-path="o.overlay_path" 
          />
        </div>

        <!-- GIS 导出与统计 (方便截图3) -->
        <el-card shadow="hover" class="box-card mb-20">
          <template #header>
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <b>图斑空间解析与 GIS 导出</b>
              <div style="display:flex; gap:12px;">
                <el-button type="success" size="large" tag="a" :href="o.geojson_url" target="_blank">
                  一键导出 GeoJSON 矢量文件
                </el-button>
                <el-button type="warning" size="large" tag="a" :href="o.stats_url" target="_blank" plain>
                  下载区域统计 CSV
                </el-button>
              </div>
            </div>
          </template>
          
          <div style="padding: 10px 0; color:#7f8c8d; font-size:14px;">
            共检出 <b style="color:#e74c3c">{{ o.patch_count }}</b> 个有效变化图斑，总面积当量：<b style="color:#e74c3c">{{ o.total_area_px }}</b> px²。
          </div>
          <el-table :data="o.stats" max-height="300" border stripe style="width: 100%">
            <el-table-column prop="patch_id" label="图斑编号" width="120" />
            <el-table-column prop="area_px" label="投影面积(px²)" />
            <el-table-column prop="perimeter_px" label="周长(px)" />
            <el-table-column prop="complexity" label="边界复杂度(分形维度)" />
            <el-table-column prop="centroid_x" label="中心坐标(X)" />
            <el-table-column prop="centroid_y" label="中心坐标(Y)" />
          </el-table>
        </el-card>
      </div>
    </template>
  </div>
</template>

<style scoped>
.detect-page { max-width: 1440px; margin: 0 auto; padding: 20px; }
.mb-20 { margin-bottom: 20px; }
.box-card { border-radius: 12px; border: 1px solid #ebeef5; }
.box-card :deep(.el-card__header) { background-color: #fafbfc; border-bottom: 1px solid #f0f2f5; padding: 16px 20px; }

/* 炫酷上传区 */
.upload-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.upload-box { border: 2px dashed #bdc3c7; border-radius: 12px; padding: 30px; text-align: center; background: #fdfefe; transition: all 0.3s; }
.upload-box:hover { border-color: #1abc9c; background: #f0fdfa; }
.upload-title { font-size: 16px; font-weight: bold; color: #2c3e50; margin-bottom: 16px; }
.file-btn-wrap { position: relative; display: inline-block; cursor: pointer; }
.file-input { position: absolute; left: 0; top: 0; opacity: 0; width: 100%; height: 100%; cursor: pointer; }
.fake-btn { background: #34495e; color: white; padding: 12px 24px; border-radius: 6px; font-weight: bold; }

/* 计时横幅 */
.time-banner { background: #e8f8f5; border: 1px solid #1abc9c; color: #16a085; padding: 16px; border-radius: 8px; font-size: 16px; }
.time-ms { font-size: 24px; font-weight: 900; color: #e74c3c; margin: 0 6px; }

/* 出图区 */
.result-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.img-card { border-radius: 12px; }
.img-title { text-align: center; font-size: 16px; font-weight: bold; color: #2c3e50; }
.result-img { width: 100%; border-radius: 8px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }

.section-title { margin-top: 32px; margin-bottom: 16px; font-size: 24px; font-weight: 800; color: #123C3D; border-left: 6px solid #1abc9c; padding-left: 14px; }
</style>