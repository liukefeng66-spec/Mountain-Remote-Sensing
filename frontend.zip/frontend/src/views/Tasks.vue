<template>
  <div class="task-page">
    <section class="panel page-title">
      <div>
        <h2 style="margin-top:0">核查任务工作台</h2>
        <p>高风险变化图斑现场核查与闭环管理</p>
      </div>
      <el-button type="primary" @click="downloadExcel">导出 Excel</el-button>
    </section>

    <!-- 1. 任务概览 -->
    <section class="summary-grid">
      <div class="summary-card"><span>待核查</span><strong>{{ summary.pending || 0 }}</strong></div>
      <div class="summary-card danger"><span>高风险任务</span><strong>{{ summary.high_risk || 0 }}</strong></div>
      <div class="summary-card"><span>全部任务</span><strong>{{ summary.total || 0 }}</strong></div>
      <div class="summary-card success"><span>已完成</span><strong>{{ summary.finished || 0 }}</strong></div>
    </section>

    <!-- 2. 筛选区 -->
    <section class="panel filter-panel">
      <el-input v-model="filters.keyword" placeholder="任务编号 / 图斑编号" clearable />
      <el-select v-model="filters.risk" placeholder="风险等级" clearable>
        <el-option label="极高" value="极高" />
        <el-option label="高" value="高" />
        <el-option label="中" value="中" />
        <el-option label="低" value="低" />
      </el-select>
      <el-select v-model="filters.status" placeholder="任务状态" clearable>
        <el-option label="待核查" value="待核查" />
        <el-option label="核查中" value="核查中" />
        <el-option label="已核查" value="已核查" />
        <el-option label="需复核" value="需复核" />
      </el-select>
      <el-select v-model="filters.priority" placeholder="优先级" clearable>
        <el-option label="立即核查" value="立即核查" />
        <el-option label="优先核查" value="优先核查" />
        <el-option label="常规核查" value="常规核查" />
        <el-option label="暂缓核查" value="暂缓核查" />
      </el-select>
      <el-button type="primary" @click="loadTasks">查询</el-button>
      <el-button @click="resetFilters">重置</el-button>
    </section>

    <!-- 3. 任务表 -->
    <section class="panel">
      <el-table :data="tasks" stripe>
        <el-table-column prop="task_code" label="任务编号" min-width="150" />
        <el-table-column prop="patch_code" label="图斑" width="80" />
        <el-table-column prop="change_type" label="类型" width="120" />
        <el-table-column label="风险" width="80">
          <template #default="{ row }">
            <el-tag :type="riskTagType(row.risk_level)" effect="dark">{{ row.risk_level }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="面积" width="100">
          <template #default="{ row }">{{ Number(row.area_m2 || 0).toFixed(1) }} px²</template>
        </el-table-column>
        <el-table-column prop="priority" label="优先级" width="110" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openDetail(row)">查看/反馈</el-button>
            <el-button v-if="row.status === '待核查'" link @click="markChecking(row)">开始</el-button>
          </template>
        </el-table-column>
      </el-table>
    </section>

    <!-- 4. 任务详情抽屉 -->
    <el-drawer v-model="drawerVisible" title="核查任务详情" size="520px">
      <template v-if="currentTask">
        <div class="detail-header">
          <div>
            <h2>{{ currentTask.task_code }}</h2>
            <p style="margin-top:0">对应图斑: {{ currentTask.patch_code }}</p>
          </div>
          <el-tag size="large" effect="dark" :type="riskTagType(currentTask.risk_level)">
            {{ currentTask.risk_level }}风险
          </el-tag>
        </div>
        <el-descriptions :column="2" border>
          <el-descriptions-item label="变化类型">{{ currentTask.change_type }}</el-descriptions-item>
          <el-descriptions-item label="面积">{{ Number(currentTask.area_m2 || 0).toFixed(1) }} px²</el-descriptions-item>
          <el-descriptions-item label="静态易发性">{{ currentTask.susceptibility_level }}</el-descriptions-item>
          <el-descriptions-item label="降雨预警">{{ currentTask.rain_level }}</el-descriptions-item>
          <el-descriptions-item label="核查优先级">{{ currentTask.priority }}</el-descriptions-item>
          <el-descriptions-item label="任务状态">
             <el-tag :type="statusTagType(currentTask.status)" size="small">{{ currentTask.status }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="经纬度/坐标" :span="2">
            X: {{ currentTask.centroid_lon || '-' }}, Y: {{ currentTask.centroid_lat || '-' }}
          </el-descriptions-item>
        </el-descriptions>

        <div class="reason-box">
          <h3 style="margin-top:0">风险判定依据</h3>
          <p>{{ currentTask.risk_reason || '暂无风险解释' }}</p>
        </div>
        <div class="reason-box">
          <h3 style="margin-top:0">系统建议</h3>
          <p style="font-weight:bold; color:#e74c3c;">{{ currentTask.suggestion || '常规现场核查' }}</p>
        </div>

        <!-- 5. 核查反馈 -->
        <el-divider>现场核查反馈</el-divider>
        <div v-if="currentTask.feedback_result" style="margin-bottom:18px">
          <el-alert title="此任务已提交核查反馈" type="success" :closable="false" />
          <p><b>核查结论:</b> {{ currentTask.feedback_result }}</p>
          <p><b>现场说明:</b> {{ currentTask.feedback_desc }}</p>
          <div v-if="currentTask.photo_path">
             <b>现场照片:</b><br/>
             <img :src="currentTask.photo_path" style="max-width:100%; max-height:200px; border-radius:8px; margin-top:8px" />
          </div>
        </div>

        <el-form label-position="top" v-else>
          <el-form-item label="核查结论">
            <el-radio-group v-model="feedback.result">
              <el-radio value="确认变化" label="确认变化" />
              <el-radio value="误报" label="误报" />
              <el-radio value="需复核" label="需复核" />
            </el-radio-group>
          </el-form-item>
          <el-form-item label="现场情况说明">
            <el-input v-model="feedback.description" type="textarea" :rows="3" placeholder="请输入现场核查情况，例如：经现场确认，为新建违章建筑..." />
          </el-form-item>
          <el-form-item label="现场照片 (可选)">
            <input type="file" accept="image/*" @change="onPhotoChange" />
          </el-form-item>
          <el-button type="primary" :loading="submitting" @click="submitFeedback" style="width:100%">
            提交核查结果
          </el-button>
        </el-form>
      </template>
    </el-drawer>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getTaskSummary, getTasks, getTaskDetail, updateTaskStatus, submitTaskFeedback, exportTaskExcel } from '../api/tasks.js'

const tasks = ref([])
const summary = reactive({ pending: 0, high_risk: 0, total: 0, finished: 0 })
const filters = reactive({ keyword: '', risk: '', status: '', priority: '' })

const drawerVisible = ref(false)
const currentTask = ref(null)
const photoFile = ref(null)
const submitting = ref(false)
const feedback = reactive({ result: '确认变化', description: '' })

const riskTagType = (level) => ({ '极高': 'danger', '高': 'warning', '中': '', '低': 'success' }[level] || 'info')
const statusTagType = (status) => ({ '待核查': 'warning', '核查中': '', '已核查': 'success', '需复核': 'danger' }[status] || 'info')

const loadSummary = async () => {
  try {
    const { data } = await getTaskSummary()
    Object.assign(summary, data)
  } catch(e) {}
}

const loadTasks = async () => {
  try {
    const { data } = await getTasks(filters)
    tasks.value = data.items || []
  } catch(e) {}
}

const resetFilters = () => {
  filters.keyword = ''; filters.risk = ''; filters.status = ''; filters.priority = '';
  loadTasks()
}

const openDetail = async (row) => {
  try {
    const { data } = await getTaskDetail(row.id)
    currentTask.value = data
    drawerVisible.value = true
    feedback.result = '确认变化'
    feedback.description = ''
    photoFile.value = null
  } catch(e) { ElMessage.error('无法读取任务详情') }
}

const markChecking = async (row) => {
  try {
    await updateTaskStatus(row.id, '核查中')
    ElMessage.success('任务已更新为核查中')
    await Promise.all([loadTasks(), loadSummary()])
  } catch(e) {}
}

const onPhotoChange = (e) => { photoFile.value = e.target.files?.[0] || null }

const submitFeedback = async () => {
  if (!currentTask.value) return
  const formData = new FormData()
  formData.append('result', feedback.result)
  formData.append('description', feedback.description)
  if (photoFile.value) formData.append('photo', photoFile.value)

  submitting.value = true
  try {
    await submitTaskFeedback(currentTask.value.id, formData)
    ElMessage.success('核查结果已保存')
    drawerVisible.value = false
    await Promise.all([loadTasks(), loadSummary()])
  } catch(e) {
    ElMessage.error('提交失败')
  } finally {
    submitting.value = false
  }
}

const downloadExcel = async () => {
  try {
    const response = await exportTaskExcel()
    const url = URL.createObjectURL(response.data)
    const a = document.createElement('a')
    a.href = url
    a.download = '核查任务清单.xlsx'
    a.click()
    URL.revokeObjectURL(url)
  } catch(e) { ElMessage.error('导出失败') }
}

onMounted(() => {
  loadTasks()
  loadSummary()
})
</script>

<style scoped>
.task-page { padding: 8px 0; }
.panel { background: #fff; border-radius: 12px; padding: 22px; border: 1px solid #e4eeeb; margin-bottom: 18px; }
.page-title { display: flex; align-items: center; justify-content: space-between; }
.page-title h2 { margin: 0; }
.page-title p { margin: 6px 0 0; color: #7b8b8f; font-size: 13px; }
.summary-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 18px; }
.summary-card { background: #fff; border-radius: 12px; padding: 18px; border: 1px solid #e4eeeb; }
.summary-card span { display: block; color: #7a8a8e; font-size: 13px; }
.summary-card strong { display: block; margin-top: 8px; font-size: 28px; color: #123c3d; }
.summary-card.danger { border-left: 5px solid #e74c3c; }
.summary-card.success { border-left: 5px solid #2ecc71; }
.filter-panel { display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr auto auto; gap: 12px; align-items: center; }
.detail-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 18px; }
.reason-box { margin-top: 16px; padding: 16px; border-radius: 8px; background: #f9fbfb; border: 1px solid #eef3f2; }
.reason-box p { margin: 6px 0 0 0; font-size: 14px; }
</style>