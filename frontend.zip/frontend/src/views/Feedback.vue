<template>
  <div class="feedback-page">
    <section class="page-header">
      <div>
        <h2 style="margin: 0 0 4px 0; font-size: 22px; color: #123C3D;">反馈样本工作台</h2>
        <p style="margin: 0; color: #71858a; font-size: 13px;">记录核查结果并沉淀人工审核样本，供后续离线增量训练使用</p>
      </div>
      <el-button type="primary" size="default" @click="downloadExcel">导出已确认样本 (Excel)</el-button>
    </section>

    <!-- 1. 统计卡片 -->
    <section class="summary-grid">
      <div class="summary-card"><span>全部反馈</span><strong>{{ summary.total || 0 }}</strong></div>
      <div class="summary-card warning"><span>误报 (负样本)</span><strong>{{ summary.false_positive || 0 }}</strong></div>
      <div class="summary-card danger"><span>漏报 (正样本)</span><strong>{{ summary.false_negative || 0 }}</strong></div>
      <div class="summary-card success"><span>确认正确</span><strong>{{ summary.correct || 0 }}</strong></div>
      <div class="summary-card"><span>待审核 (需确认)</span><strong>{{ summary.pending || 0 }}</strong></div>
    </section>

    <!-- 2 & 3. 左右分栏容器 -->
    <el-row :gutter="16" style="display: flex; align-items: stretch;">
      <!-- 2. 新增反馈表单 -->
      <el-col :span="9">
        <el-card class="box-card" shadow="never">
          <template #header><b style="font-size:14px">📝 新增现场反馈</b></template>
          <el-form label-position="top" size="small">
            <el-form-item label="关联核查任务 (自动带入上下文)" style="margin-bottom:8px">
              <el-select v-model="form.task_id" filterable placeholder="选择任务..." style="width: 100%">
                <el-option v-for="item in taskOptions" :key="item.id" :value="item.id" :label="item.task_code + ' - 图斑' + item.patch_code" />
              </el-select>
            </el-form-item>

            <div v-if="selectedTask" class="context-box">
              <el-row :gutter="8">
                <el-col :span="12"><span>图斑编号</span><b>{{ selectedTask.patch_code }}</b></el-col>
                <el-col :span="12"><span>风险等级</span><b style="color:#e74c3c">{{ selectedTask.risk_level }}</b></el-col>
                <el-col :span="12" style="margin-top:6px"><span>变化类型</span><b>{{ selectedTask.change_type }}</b></el-col>
                <el-col :span="12" style="margin-top:6px"><span>任务状态</span><b>{{ selectedTask.status }}</b></el-col>
              </el-row>
            </div>

            <el-form-item label="现场核查结论" style="margin-top:12px; margin-bottom:12px">
              <el-radio-group v-model="form.feedback_type">
                <el-radio-button value="误报" label="误报" />
                <el-radio-button value="漏报" label="漏报" />
                <el-radio-button value="确认正确" label="确认正确" />
                <el-radio-button value="需复核" label="需复核" />
              </el-radio-group>
            </el-form-item>

            <el-form-item label="补充照片/截图 (可选)" style="margin-bottom:12px">
              <div style="display:flex; gap:10px; width:100%">
                <div class="file-btn"><span>📸 现场照片</span><input type="file" accept="image/*" @change="onSitePhotoChange" /></div>
                <div class="file-btn"><span>🖼️ 标注截图</span><input type="file" accept="image/*" @change="onAnnotationChange" /></div>
              </div>
              <small v-if="sitePhoto" style="color:#2ecc71; display:block; line-height:1.2; margin-top:4px">已选: {{sitePhoto.name}}</small>
              <small v-if="annotation" style="color:#2ecc71; display:block; line-height:1.2; margin-top:4px">已选: {{annotation.name}}</small>
            </el-form-item>

            <el-form-item label="现场备注" style="margin-bottom:12px">
              <el-input v-model="form.note" type="textarea" :rows="2" placeholder="填写现场情况..." />
            </el-form-item>

            <el-button type="primary" :loading="saving" @click="saveFeedback" style="width:100%; margin-top:5px" size="default">
              提交反馈至样本库
            </el-button>
          </el-form>
        </el-card>
      </el-col>

      <!-- 3. 历史反馈列表 -->
      <el-col :span="15">
        <el-card class="box-card" shadow="never" style="display:flex; flex-direction:column;">
          <template #header>
            <div style="display:flex; justify-content:space-between; align-items:center">
              <b style="font-size:14px">🗄️ 历史反馈与样本审核</b>
              <div style="display:flex; gap:8px;">
                <el-select size="small" v-model="filters.feedback_type" placeholder="类型" clearable style="width:90px"><el-option label="误报" value="误报"/><el-option label="确认正确" value="确认正确"/><el-option label="漏报" value="漏报"/></el-select>
                <el-select size="small" v-model="filters.review_status" placeholder="状态" clearable style="width:90px"><el-option label="待审核" value="待审核"/><el-option label="已确认" value="已确认"/><el-option label="已作废" value="已作废"/></el-select>
                <el-button size="small" type="primary" @click="loadFeedbackList">查询</el-button>
              </div>
            </div>
          </template>

          <el-table :data="feedbackList" stripe style="width:100%; flex:1;" size="small">
            <el-table-column prop="feedback_code" label="反馈编号" min-width="120" show-overflow-tooltip/>
            <el-table-column prop="patch_code" label="图斑" width="70" />
            <el-table-column label="结论" width="85">
              <template #default="{ row }"><el-tag :type="feedbackTagType(row.feedback_type)" size="small">{{ row.feedback_type }}</el-tag></template>
            </el-table-column>
            <el-table-column label="审核" width="75">
              <template #default="{ row }"><el-tag :type="reviewTagType(row.review_status)" size="small" effect="plain">{{ row.review_status }}</el-tag></template>
            </el-table-column>
            <el-table-column prop="note" label="备注" show-overflow-tooltip min-width="120" />
            <el-table-column label="操作" width="135" fixed="right">
              <template #default="{ row }">
                <el-button link type="primary" size="small" @click="openDetail(row)">详情</el-button>
                <el-button v-if="row.review_status === '待审核'" link type="success" size="small" @click="confirmSample(row)">确认</el-button>
                <el-button v-if="row.review_status !== '已作废'" link type="danger" size="small" @click="invalidateSample(row)">作废</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 4. 详情抽屉 -->
    <el-drawer v-model="detailVisible" title="反馈样本详情" size="520px">
      <template v-if="currentSample">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="反馈编号">{{ currentSample.feedback_code }}</el-descriptions-item>
          <el-descriptions-item label="关联任务">{{ currentSample.task_code }}</el-descriptions-item>
          <el-descriptions-item label="关联图斑">{{ currentSample.patch_code }}</el-descriptions-item>
          <el-descriptions-item label="结论"><b>{{ currentSample.feedback_type }}</b></el-descriptions-item>
          <el-descriptions-item label="风险背景">{{ currentSample.risk_level }}</el-descriptions-item>
          <el-descriptions-item label="模型置信度">{{ percent(currentSample.confidence) }}</el-descriptions-item>
          <el-descriptions-item label="人工备注">{{ currentSample.note || '无' }}</el-descriptions-item>
        </el-descriptions>
        <div v-if="currentSample.site_photo_path" style="margin-top:15px">
          <b>现场照片:</b><br/>
          <img :src="currentSample.site_photo_path" style="max-width:100%; border-radius:8px; margin-top:8px" />
        </div>
        <div v-if="currentSample.annotation_path" style="margin-top:15px">
          <b>补充截图:</b><br/>
          <img :src="currentSample.annotation_path" style="max-width:100%; border-radius:8px; margin-top:8px" />
        </div>
      </template>
    </el-drawer>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getFeedbackSummary, getTaskOptions, getFeedbackList, createFeedback, updateFeedbackReview, exportFeedbackExcel } from '../api/feedback.js'
import { useRoute } from 'vue-router'

const route = useRoute()
const summary = reactive({ total: 0, false_positive: 0, false_negative: 0, correct: 0, pending: 0 })
const taskOptions = ref([])
const feedbackList = ref([])
const saving = ref(false)
const sitePhoto = ref(null)
const annotation = ref(null)
const detailVisible = ref(false)
const currentSample = ref(null)

const form = reactive({ task_id: null, feedback_type: '误报', note: '' })
const filters = reactive({ feedback_type: '', review_status: '', keyword: '' })

const selectedTask = computed(() => taskOptions.value.find(x => x.id === form.task_id) || null)
const percent = (v) => `${(Number(v || 0) * 100).toFixed(1)}%`
const feedbackTagType = (type) => ({ '误报': 'warning', '漏报': 'danger', '确认正确': 'success' }[type] || 'info')
const reviewTagType = (status) => ({ '待审核': 'warning', '已确认': 'success', '已作废': 'info' }[status] || 'info')

const loadData = async () => {
  try {
    const [s, t, l] = await Promise.all([getFeedbackSummary(), getTaskOptions(), getFeedbackList(filters)])
    Object.assign(summary, s.data)
    taskOptions.value = t.data
    feedbackList.value = l.data
  } catch(e) {}
}

const loadFeedbackList = async () => {
  const { data } = await getFeedbackList(filters)
  feedbackList.value = data
}

const onSitePhotoChange = (e) => { sitePhoto.value = e.target.files?.[0] || null }
const onAnnotationChange = (e) => { annotation.value = e.target.files?.[0] || null }

const saveFeedback = async () => {
  if (!form.task_id) return ElMessage.warning('请选择要反馈的核查任务')
  const fd = new FormData()
  fd.append('task_id', form.task_id)
  fd.append('feedback_type', form.feedback_type)
  fd.append('note', form.note)
  if (sitePhoto.value) fd.append('site_photo', sitePhoto.value)
  if (annotation.value) fd.append('annotation', annotation.value)

  saving.value = true
  try {
    await createFeedback(fd)
    ElMessage.success('成功加入反馈样本库！')
    form.note = ''; sitePhoto.value = null; annotation.value = null
    await loadData()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '保存失败 (可能是重复反馈)')
  } finally {
    saving.value = false
  }
}

const openDetail = (row) => { currentSample.value = row; detailVisible.value = true }
const confirmSample = async (row) => {
  await updateFeedbackReview(row.id, '已确认')
  ElMessage.success('该样本审核通过，后续将用于训练')
  await loadData()
}
const invalidateSample = async (row) => {
  await ElMessageBox.confirm('作废后将不会用于模型训练，是否继续？', '提示', { type: 'warning' })
  await updateFeedbackReview(row.id, '已作废')
  ElMessage.success('已作废')
  await loadData()
}

const downloadExcel = async () => {
  try {
    const response = await exportFeedbackExcel()
    const url = URL.createObjectURL(response.data)
    const a = document.createElement('a')
    a.href = url
    a.download = '反馈训练样本.xlsx'
    a.click()
    URL.revokeObjectURL(url)
  } catch(e) { ElMessage.error('导出失败') }
}

onMounted(() => {
  loadData().then(() => {
    if(route.query.task_id) form.task_id = Number(route.query.task_id)
  })
})
</script>

<style>
.feedback-page .el-card__header { padding: 10px 15px; border-bottom: 1px solid #f0f0f0; }
.feedback-page .el-card__body { padding: 15px; flex: 1; display: flex; flex-direction: column; }
</style>

<style scoped>
.feedback-page { 
  padding: 8px 16px; 
  max-width: 1600px;
  margin: 0 auto;
  width: 100%;
}

.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.summary-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 16px; }

.summary-card { background: #fff; border-radius: 8px; padding: 12px 16px; border: 1px solid #eef3f2; box-shadow: 0 2px 8px rgba(0,0,0,0.02); }
.summary-card span { color: #819194; display: block; font-size: 13px; }
.summary-card strong { display: block; margin-top: 6px; font-size: 24px; color: #123c3d; line-height: 1; }
.summary-card.warning { border-left: 4px solid #e6a23c; }
.summary-card.danger { border-left: 4px solid #f56c6c; }
.summary-card.success { border-left: 4px solid #67c23a; }

.box-card { border-radius: 8px; border: 1px solid #e4eeeb; height: 100%; box-sizing: border-box; }

.context-box { margin-top: 5px; padding: 10px; background: #f9fbfb; border-radius: 6px; border: 1px solid #eef3f2; }
.context-box span { font-size: 12px; color: #7f8c8d; display:block; margin-bottom:2px; }
.context-box b { font-size: 14px; color: #2c3e50; }

.file-btn { position: relative; overflow: hidden; background: #f0f2f5; padding: 6px 10px; border-radius: 4px; text-align: center; flex: 1; cursor: pointer; transition: 0.2s; font-size: 13px; color:#606266; }
.file-btn:hover { background: #e4e7ed; color: #409EFF; }
.file-btn input[type=file] { position: absolute; left: 0; top: 0; opacity: 0; width: 100%; height: 100%; cursor: pointer; }
</style>