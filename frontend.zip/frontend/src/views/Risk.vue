<template>
  <div class="risk-page">
    <div class="page-header">
      <h2>风险预估模型 (轻量化)</h2>
      <p>自动提取图像形态学特征 + 补充降雨预报 ➔ 生成业务风险判定与核查建议</p>
    </div>

    <!-- 1. 基础信息 (横向铺满，饱满展示) -->
    <el-card class="box-card mb-20" shadow="hover">
      <template #header><b>① 变化图斑基础信息</b></template>
      <el-form label-width="110px" class="full-width-form">
        <el-row :gutter="24">
          <el-col :span="6">
            <el-form-item label="任务流水号">
              <el-input v-model="form.job_id" disabled style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="图斑编号">
              <el-select v-model="selectedPatchLabel" placeholder="选择图斑" @change="handlePatchChange" style="width: 100%">
                <el-option v-for="p in patchOptions" :key="p.label" :label="p.label" :value="p.label" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="图斑面积">
              <el-input :model-value="form.area ? `${form.area} px²` : ''" disabled style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="变化类型">
              <el-input v-model="form.change_type" style="width: 100%" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <!-- 2 & 3. 因子提取 & 降雨预报 (左右对半并排，高度对齐) -->
    <el-row :gutter="20" class="mb-20">
      <!-- 左侧：形态学因子 -->
      <el-col :span="12">
        <el-card class="box-card h-100" shadow="hover">
          <template #header>
            <div class="flex-between">
              <b>② 图像与形态学因子 (CV提取)</b>
              <el-button type="primary" size="small" plain @click="extractFactors">一键模拟/提取</el-button>
            </div>
          </template>
          <el-form label-width="140px" style="padding-top: 10px;">
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="植被退化率 (VARI)">
                  <el-input v-model="form.veg_degradation" disabled style="width: 100%" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="表面粗糙度变异">
                  <el-input v-model="form.texture_variance" disabled style="width: 100%" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="边界复杂度(分形)">
                  <el-input v-model="form.boundary_complexity" disabled style="width: 100%" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="扰动面积当量">
                  <el-input v-model="form.area_px" disabled style="width: 100%">
                    <template #append>px²</template>
                  </el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="区域地貌类型">
              <el-select v-model="form.landform_type" placeholder="请选择所处地貌" style="width: 100%">
                <el-option label="高山峡谷 (高势能)" value="高山峡谷" />
                <el-option label="中山丘陵 (中势能)" value="中山丘陵" />
                <el-option label="平原盆地 (低势能)" value="平原盆地" />
              </el-select>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>

      <!-- 右侧：降雨条件 -->
      <el-col :span="12">
        <el-card class="box-card h-100" shadow="hover">
          <template #header>
            <div class="flex-between">
              <b>③ 动态降雨预报</b>
              <span style="font-size:13px; color:#909399;">暂不接实时气象API</span>
            </div>
          </template>
          <el-form label-width="120px" style="padding-top: 10px;">
            <el-form-item label="前6日雨量(mm)">
              <el-input v-model="rainText" placeholder="逗号分隔，如: 18,12,10,8,4,2" style="width: 100%" />
            </el-form-item>
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="当前强度(mm/h)">
                  <el-input-number v-model="form.current_intensity_mm_h" :min="0" style="width: 100%" :controls="false"/>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="持续时间(h)">
                  <el-input-number v-model="form.duration_h" :min="0" style="width: 100%" :controls="false"/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="未来24h预报(mm)">
              <el-input-number v-model="form.forecast_24h_mm" :min="0" style="width: 100%" :controls="false"/>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>

    <!-- 计算按钮 -->
    <div class="action-row mb-20">
      <el-button type="danger" size="large" :loading="loading" @click="calculate" class="calc-btn">
        开始一键计算综合风险
      </el-button>
    </div>

    <!-- 4. 结果卡片 -->
    <div v-if="result" class="results-area">
      <el-row :gutter="20" class="mb-20">
        <el-col :span="6">
          <div class="metric-card"><span>静态易发性</span><b>{{result.susceptibility_level}}</b><small>风险指数: {{result.susceptibility_score}}</small></div>
        </el-col>
        <el-col :span="6">
          <div class="metric-card"><span>动态降雨预报</span><b :style="{color: result.rainfall_level==='红色'?'#e74c3c':(result.rainfall_level==='橙色'?'#e67e22':(result.rainfall_level==='黄色'?'#f1c40f':'#27ae60'))}">{{result.rainfall_level}}</b><small>前期有效雨量: {{result.effective_rainfall_mm}} mm</small></div>
        </el-col>
        <el-col :span="6">
          <div class="metric-card risk-border"><span>综合风险判定</span><b style="color: #e74c3c;">{{result.risk_level}}</b><small>综合指数: {{result.overall_score}}</small></div>
        </el-col>
        <el-col :span="6">
          <div class="metric-card"><span>系统建议行动</span><b style="font-size:24px; color:#123c3d">{{result.action}}</b><small>已自动归档至核查任务</small></div>
        </el-col>
      </el-row>
      
      <el-card class="box-card" shadow="hover">
        <template #header><b>📊 风险判定依据</b></template>
        <div style="margin-bottom: 8px;">
          <el-tag size="large" v-for="(r, idx) in result.reasons" :key="idx" type="danger" effect="light" style="margin-right:12px; margin-bottom:8px; font-size:13px">{{ r }}</el-tag>
        </div>
        <p style="font-size:13px; color:#7f8c8d; margin:0; margin-top:8px">{{result.disclaimer}}</p>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage } from 'element-plus'

// 从缓存中读取最后一次任务
const last = JSON.parse(localStorage.getItem('lastJob') || 'null')

// 收集所有检测出的图斑（包括 TIDAL 和 FSD 的）
const dualStats = last?.outputs?.dual?.stats || []
const tidalStats = last?.outputs?.tidal?.stats || []
const fsdStats = last?.outputs?.fsd?.stats || []

const patchOptions = [
  ...dualStats.map(p => ({ ...p, label: `融合图斑: ${p.patch_id}`, source: 'dual' })),
  ...tidalStats.map(p => ({ ...p, label: `TIDAL: ${p.patch_id}`, source: 'tidal' })),
  ...fsdStats.map(p => ({ ...p, label: `FSD: ${p.patch_id}`, source: 'fsd' }))
]

// 默认选中第一个
const initialPatch = patchOptions.length > 0 ? patchOptions[0] : {}
const selectedPatchLabel = ref(initialPatch.label || '暂无图斑')

const form = reactive({
  job_id: last?.job_id || '未绑定',
  patch_id: initialPatch.patch_id || 'P0001',
  area: initialPatch.area_px || null,
  centroid_x: initialPatch.centroid_x || null,
  centroid_y: initialPatch.centroid_y || null,
  change_type: '疑似滑坡/地表扰动',
  
  // 图像形态学因子
  veg_degradation: initialPatch.veg_degradation || null,
  boundary_complexity: initialPatch.boundary_complexity || null,
  texture_variance: initialPatch.texture_variance || null,
  area_px: initialPatch.area_px || null,
  landform_type: '中山丘陵',
  
  rainfall_last6: [],
  current_intensity_mm_h: 35,
  duration_h: 3,
  forecast_24h_mm: 25
})

const rainText = ref('18, 12, 10, 8, 4, 2')
const result = ref(null)
const loading = ref(false)

function handlePatchChange(label) {
  const p = patchOptions.find(opt => opt.label === label)
  if (p) {
    form.patch_id = p.patch_id
    form.area = p.area_px
    form.centroid_x = p.centroid_x
    form.centroid_y = p.centroid_y
    
    // 自动切换因子
    form.veg_degradation = p.veg_degradation
    form.boundary_complexity = p.boundary_complexity
    form.texture_variance = p.texture_variance
    form.area_px = p.area_px
    
    // 清除上一次的计算结果
    result.value = null
    ElMessage.success(`已切换至图斑 ${p.label}，特征因子已同步更新！`)
  }
}

function parseRain() {
  return rainText.value.split(',').map(v => Number(v.trim())).filter(v => !isNaN(v)).slice(0, 6)
}

function extractFactors() {
  if (form.veg_degradation !== undefined && form.veg_degradation !== null) {
    ElMessage.success('已自动利用 OpenCV 重新提取表面纹理及形态学特征！')
  } else {
    // 兜底模拟
    form.veg_degradation = (Math.random() * 0.5 + 0.3).toFixed(2);
    form.boundary_complexity = (Math.random() * 2.5 + 1.5).toFixed(2);
    form.texture_variance = (Math.random() * 0.4 + 0.4).toFixed(2);
    form.area_px = Math.floor(Math.random() * 8000 + 2000);
    ElMessage.success('暂无实体图斑数据，已随机模拟提取因子。')
  }
}

async function calculate() {
  form.rainfall_last6 = parseRain()
  if(form.rainfall_last6.length === 0) return ElMessage.warning('请填写历史雨量');
  loading.value = true
  try {
    const { data } = await axios.post('/api/risk/evaluate', form)
    result.value = data
    if(['红色', '极高'].includes(data.risk_level)){
       ElMessage.success('计算完成，高风险图斑已发至核查任务列表！')
    } else {
       ElMessage.success('计算完成！')
    }
  } catch (e) {
    ElMessage.error(e?.response?.data?.detail || '计算失败')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.risk-page { padding: 24px 32px; max-width: 1440px; margin: 0 auto; }
.page-header { margin-bottom: 24px; }
.page-header h2 { margin: 0 0 8px 0; font-size: 26px; color: #123C3D; font-weight: 700; }
.page-header p { margin: 0; color: #71858a; font-size: 15px; }

.mb-20 { margin-bottom: 20px; }
.box-card { border-radius: 12px; border: 1px solid #ebeef5; }
.box-card :deep(.el-card__header) { background-color: #fafbfc; border-bottom: 1px solid #f0f2f5; padding: 16px 20px; }
.h-100 { height: 100%; box-sizing: border-box; }
.flex-between { display: flex; justify-content: space-between; align-items: center; }

/* 修复挤压问题：确保内部元素可以正常撑开 */
.full-width-form { padding: 10px 0; }

.action-row { text-align: center; margin: 24px 0; }
.calc-btn { width: 340px; font-size: 18px; font-weight: bold; border-radius: 8px; padding: 22px 0; box-shadow: 0 6px 16px rgba(231, 76, 60, 0.25); transition: all 0.2s;}
.calc-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(231, 76, 60, 0.35); }

.results-area { animation: fadeIn 0.4s ease-out; }
.metric-card { 
  padding: 18px 24px; 
  background: #fff; 
  border-radius: 12px; 
  display: flex; 
  flex-direction: column; 
  gap: 8px; 
  box-shadow: 0 4px 12px rgba(0,0,0,0.04);
  border: 1px solid #ebeef5;
  height: 100%; 
  box-sizing: border-box;
  transition: transform 0.2s;
}
.metric-card:hover { transform: translateY(-3px); box-shadow: 0 8px 16px rgba(0,0,0,0.06); }
.metric-card span { font-size: 14px; color: #71858a; }
.metric-card b { font-size: 28px; color: #123C3D; line-height: 1.2; font-weight: 800; }
.metric-card small { font-size: 13px; color: #a1b5ba; margin-top: 4px; }
.risk-border { border: 2px solid #e74c3c; background: #fffefd; }

@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
</style>