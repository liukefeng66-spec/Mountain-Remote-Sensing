<template>
<div class="shell">
  <aside class="sidebar">
    <div class="brand">
      <div class="logo">ME</div>
      <div><b>山地慧眼</b><small>智慧水土 · MountainEye</small></div>
    </div>
    <nav>
      <RouterLink to="/">态势总览</RouterLink>
      <RouterLink to="/detect">双域智能检测</RouterLink>
      <RouterLink to="/risk">风险预估</RouterLink>
      <RouterLink to="/tasks">核查任务</RouterLink>
      <RouterLink to="/feedback">反馈样本</RouterLink>
    </nav>
    <div class="side-foot">Challenge Cup Demo<br/>TIDAL-Net × FSD-Net</div>
  </aside>
  <main>
    <header>
      <div><strong>西南山地山洪地灾与水保遥感智能监测系统</strong><span>空天地采集 · 双域检测 · 图斑解析 · 风险预估 · 核查反馈</span></div>
      <el-tag type="success" effect="dark">系统在线</el-tag>
    </header>
    <section class="page">
      <RouterView/>
    </section>
  </main>
</div>
</template>