import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from './views/Dashboard.vue'
import Detect from './views/Detect.vue'
import Risk from './views/Risk.vue'
import Tasks from './views/Tasks.vue'
import Feedback from './views/Feedback.vue'
export default createRouter({
  history:createWebHistory(),
  routes:[
    {path:'/',component:Dashboard},
    {path:'/detect',component:Detect},
    {path:'/risk',component:Risk},
    {path:'/tasks',component:Tasks},
    {path:'/feedback',component:Feedback}
  ]
})