﻿import codecs

detect_vue = '''<script setup>
import {ref, onMounted} from 'vue'; 
import axios from 'axios'; 
import {ElMessage} from 'element-plus';
import TriptychPanel from '../components/TriptychPanel.vue';

const t1=ref(null),t2=ref(null),model=ref('both'),threshold=ref(0.5),loading=ref(false),res=ref(null)
const pick=(e,k)=>{ if(k===1)t1.value=e.target.files[0]; else t2.value=e.target.files[0] }

onMounted(() => {
  const saved = localStorage.getItem('lastJob');
  if (saved) {
    try { res.value = JSON.parse(saved); } catch(e){}
  }
});

async function run(){
  if(!t1.value||!t2.value)return ElMessage.warning('请先选择 T1 和 T2');
  loading.value=true;
  const fd=new FormData();
  fd.append('t1',t1.value); fd.append('t2',t2.value);
  fd.append('model',model.value); fd.append('threshold',threshold.value);
  try{
    res.value=(await axios.post('/api/detect',fd)).data;
    localStorage.setItem('lastJob',JSON.stringify(res.value));
    ElMessage.success('推理完成')
  }catch(e){
    ElMessage.error(e.response?.data?.detail||e.message)
  }finally{
    loading.value=false
  }
}
</script>

<template>
  <div class="card">
    <div class="toolbar">
      <el-select v-model="model" style="width:180px">
        <el-option label="双模型对比" value="both"/>
        <el-option label="TIDAL-Net" value="tidal"/>
        <el-option label="FSD-Net" value="fsd"/>
      </el-select>
      <span>阈值</span>
      <el-slider v-model="threshold" :min="0.01" :max="0.9" :step="0.01" style="width:220px"/>
      <el-button type="primary" :loading="loading" @click="run">开始推理</el-button>
    </div>
    <div class="upload-grid" style="margin-top:18px">
      <div><b>时相 T1</b><input type="file" @change="e=>pick(e,1)"/></div>
      <div><b>时相 T2</b><input type="file" @change="e=>pick(e,2)"/></div>
    </div>
  </div>
  <template v-if="res">
    <div v-for="(o,name) in res.outputs" :key="name">
      <div class="section-title">{{name.toUpperCase()}} 结果 · {{o.patch_count}} 个图斑</div>
      <div class="result-grid">
        <div class="card"><b>变化概率图</b><img class="result-img" :src="o.prob_url"/></div>
        <div class="card"><b>二值变化图</b><img class="result-img" :src="o.binary_url"/></div>
      </div>
      <div class="card" style="margin-top:14px">
        <a :href="o.geojson_url" target="_blank">下载 GeoJSON</a>　<a :href="o.stats_url" target="_blank">下载统计 CSV</a>
        <el-table :data="o.stats" max-height="320" style="margin-top:12px">
          <el-table-column prop="patch_id" label="图斑"/>
          <el-table-column prop="area_px" label="面积(px²)"/>
          <el-table-column prop="perimeter_px" label="周长(px)"/>
          <el-table-column prop="centroid_x" label="质心X"/>
          <el-table-column prop="centroid_y" label="质心Y"/>
        </el-table>
      </div>
      <TriptychPanel
        :image-a-url="o.image_a_url"
        :image-b-url="o.image_b_url"
        :result-url="o.overlay_url"
        :image-a-path="o.image_a_path"
        :image-b-path="o.image_b_path"
        :result-path="o.overlay_path"
      />
    </div>
  </template>
</template>
'''

with codecs.open('E:/PycharmProjects/website/frontend/src/views/Detect.vue', 'w', 'utf-8') as f:
    f.write(detect_vue)