import os, sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../../..')   
   
import warnings
warnings.filterwarnings('ignore')     
from calflops import calculate_flops 
   
import torch
import torch.nn as nn
import torch.nn.functional as F     
    
from .conv import Conv, DSConv


class DRB(nn.Module):
    def __init__(self, inc,dropout_rate=0.1):
        super().__init__()
     
        self.conv3x3_1 = Conv(inc, inc, 3, act=nn.SiLU())
        self.conv3x3_2 = Conv(inc // 4, inc // 4, 3, act=nn.SiLU())
        self.norm = nn.BatchNorm2d(inc // 4)
        self.dropout = nn.Dropout2d(p=dropout_rate)
        self.convblock = DSConv(inc // 4, inc, 3, act=nn.SiLU())
  
    def forward(self, x):    
        x = self.conv3x3_1(x)
        x = F.pixel_shuffle(x, upscale_factor=2)
        x = self.norm(x)
        x = self.dropout(x)
        x = self.conv3x3_2(x)  
        x = self.convblock(x)    
        return x 
  
if __name__ == '__main__':     
    RED, GREEN, BLUE, YELLOW, ORANGE, RESET = "\033[91m", "\033[92m", "\033[94m", "\033[93m", "\033[38;5;208m", "\033[0m"   
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')   
    batch_size, channel, height, width = 32, 64, 256, 256
    inputs = torch.randn((batch_size, channel, height, width)).to(device)
 
    module = DRB(channel).to(device)

    outputs = module(inputs)   
    print(GREEN + f'inputs.size:{inputs.size()} outputs.size:{outputs.size()}' + RESET)

    print(ORANGE)    
    flops, macs, _ = calculate_flops(model=module,     
                                     input_shape=(batch_size, channel, height, width),
                                     output_as_string=True,
                                     output_precision=4,    
                                     print_detailed=True)
    print(RESET)     
